<?php

include '../config/db.php';
include '../mikrotik/functions.php';

$dueBills = mysqli_query($conn,"
SELECT b.*, m.ip, m.username, m.password, m.port
FROM billings b
JOIN mikrotik_servers m ON b.mikrotik_id = m.id
WHERE b.status != 'Paid' AND b.due_amount > 0
");

while($bill = mysqli_fetch_assoc($dueBills)){

    $server = [
        'ip' => $bill['ip'],
        'username' => $bill['username'],
        'password' => $bill['password'],
        'port' => $bill['port']
    ];

    if($bill['ppp_username']){
        mikrotik_disable($server, $bill['ppp_username']);
    }
}

echo "DONE";

?>