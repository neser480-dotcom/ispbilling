<?php
include '../config/db.php';

$id = $_GET['id'];

$reseller = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM staff WHERE id='$id'"));

$customers = mysqli_query($conn,"SELECT * FROM customers WHERE reseller_id='$id'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>ISP Reseller System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #eef2f7;
        }

        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg,#111827,#1f2937);
            color: white;
            position: fixed;
            padding: 15px;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            border-radius: 6px;
        }

        .sidebar a:hover {
            background: #374151;
        }

        .topbar {
            margin-left: 250px;
            background: #fff;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .main {
            margin-left: 250px;
            padding: 20px;
        }

        .card-box {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
    </style>
</head>

<body>

<div class="sidebar">
    <h4>ISP PANEL</h4>
    <hr>
    <a href="../dashboard.php">🏠 Dashboard</a>
    <a href="../staff/reseller.php">🤝 Reseller</a>
    <a href="../staff/reseller_add.php">➕ Add Reseller</a>
    <a href="../staff/reseller_report.php">📊 Report</a>
</div>

<div class="topbar">
    <b>Reseller Management System</b>
</div>

<div class="main">
<div class="card-box">
<h3>Reseller: <?= $reseller['name'] ?></h3>

<h5>Clients</h5>

<table class="table table-bordered">
<tr>
    <th>Name</th>
    <th>Package</th>
    <th>Bill</th>
</tr>

<?php 
$total = 0;
while($c = mysqli_fetch_assoc($customers)){ 
$total += $c['bill'];
?>
<tr>
    <td><?= $c['name'] ?></td>
    <td><?= $c['package'] ?></td>
    <td><?= $c['bill'] ?></td>
</tr>
<?php } ?>

</table>

<hr>

<h4>Total Business: <?= $total ?> TK</h4>
</div>

<?php include '../includes/footer.php'; ?>