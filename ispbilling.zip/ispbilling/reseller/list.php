<?php
include '../config/db.php';

$data = mysqli_query($conn,"SELECT * FROM staff WHERE role='Reseller'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>ISP Reseller System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #eef2f7;
        }

        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg,#111827,#1f2937);
            color: white;
            position: fixed;
            padding: 15px;
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            border-radius: 6px;
        }

        .sidebar a:hover {
            background: #374151;
        }

        .topbar {
            margin-left: 250px;
            background: #fff;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .main {
            margin-left: 250px;
            padding: 20px;
        }

        .card-box {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
    </style>
</head>

<body>

<div class="sidebar">
    <h4>ISP PANEL</h4>
    <hr>
    <a href="../dashboard.php">🏠 Dashboard</a>
    <a href="../staff/reseller.php">🤝 Reseller</a>
    <a href="../staff/reseller_add.php">➕ Add Reseller</a>
    <a href="../staff/reseller_report.php">📊 Report</a>
</div>

<div class="topbar">
    <b>Reseller Management System</b>
</div>

<div class="main">
<div class="card-box">
<h3>Reseller List</h3>

<a class="btn btn-primary btn-sm" href="reseller_add.php">+ Add Reseller</a>

<br><br>

<table class="table table-bordered">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Phone</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($data)){ ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['name'] ?></td>
    <td><?= $row['phone'] ?></td>
    <td>
        <a class="btn btn-success btn-sm" href="reseller_view.php?id=<?= $row['id'] ?>">View</a>
    </td>
</tr>
<?php } ?>

</table>
</div>

<?php include '../includes/footer.php'; ?>