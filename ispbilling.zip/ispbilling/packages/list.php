<?php

include '../includes/auth.php';
include '../config/db.php';

$data = mysqli_query($conn,"
SELECT * FROM packages
ORDER BY id DESC
");

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-primary text-white">
Package List
</div>

<div class="card-body">

<a href="add.php"
class="btn btn-success mb-3">
Add Package
</a>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Name</th>
<th>Speed</th>
<th>Price</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>
<td><?= $row['package_name'] ?></td>
<td><?= $row['speed'] ?></td>
<td><?= $row['price'] ?></td>

<td>

<a href="edit.php?id=<?= $row['id'] ?>"
class="btn btn-warning btn-sm">
Edit
</a>

<a href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Package?')">
Delete
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

<?php include '../includes/footer.php'; ?>