<?php
include '../includes/auth.php';
include '../config/db.php';

if(isset($_POST['save']))
{
    $package_name = $_POST['package_name'];
    $speed = $_POST['speed'];
    $price = $_POST['price'];

    mysqli_query($conn,"
    INSERT INTO packages
    (package_name,speed,price)
    VALUES
    ('$package_name','$speed','$price')
    ");

    header("Location:list.php");
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
<div class="card-header bg-success text-white">
Add Package
</div>

<div class="card-body">

<form method="POST">

<input type="text"
name="package_name"
class="form-control mb-3"
placeholder="Package Name"
required>

<input type="text"
name="speed"
class="form-control mb-3"
placeholder="10 Mbps">

<input type="number"
name="price"
class="form-control mb-3"
placeholder="1000"
required>

<button type="submit"
name="save"
class="btn btn-success">
Save Package
</button>

</form>

</div>
</div>

<?php include '../includes/footer.php'; ?>