<?php

include '../includes/auth.php';
include '../config/db.php';

$id = intval($_GET['id']);

$data = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT * FROM packages
WHERE id='$id'
")
);

if(isset($_POST['update']))
{
    mysqli_query($conn,"
    UPDATE packages SET

    package_name='".$_POST['package_name']."',
    speed='".$_POST['speed']."',
    price='".$_POST['price']."'

    WHERE id='$id'
    ");

    header("Location:list.php");
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-warning">
Edit Package
</div>

<div class="card-body">

<form method="POST">

<input type="text"
name="package_name"
class="form-control mb-3"
value="<?= $data['package_name'] ?>">

<input type="text"
name="speed"
class="form-control mb-3"
value="<?= $data['speed'] ?>">

<input type="number"
name="price"
class="form-control mb-3"
value="<?= $data['price'] ?>">

<button type="submit"
name="update"
class="btn btn-success">
Update Package
</button>

</form>

</div>

</div>

<?php include '../includes/footer.php'; ?>