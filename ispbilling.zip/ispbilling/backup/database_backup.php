<?php

include '../includes/auth.php';

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ispbilling";

$backup_file =
$dbname . "_backup_" .
date("Y-m-d_H-i-s") .
".sql";

header('Content-Type: application/octet-stream');
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=".$backup_file);

system(
"mysqldump --host=$host --user=$user $dbname"
);
exit();
?>