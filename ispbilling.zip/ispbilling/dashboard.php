<?php
session_start();
include 'config/db.php';


include 'config/db.php';
include 'includes/sidebar.php';
include 'includes/topbar.php';

$total_bill = 520000;
$total_collection = 245000;

$percent = ($total_bill > 0)
    ? round(($total_collection / $total_bill) * 100)
    : 0;

$radius = 80;
$circumference = 2 * pi() * $radius;
$offset = $circumference - ($percent / 100) * $circumference;

$total_customer = 520;
$active_customer = 487;
$inactive_customer = 33;
$expired_customer = 15;

$paid_customer = 420;
$unpaid_customer = 100;
$free_customer = 25;

$total_bill = 520000;

$total_collection = 245000;
$today_collection = 8500;

$connection_fee = 75000;
$total_discount = 12000;

$total_expense = 45000;
$total_salary = 60000;

$business_balance = 203000;

$online_user = 487;
$offline_user = 33;
$total_pppoe = 520;
$mikrotik_total = 3;

$deposit_collection = 15000;
$total_message = 152;

$all_collector = 5;

$collector_connection_fee = 25000;
$collector_deposit = 8000;
$collector_expense = 3000;
$collector_balance = 22000;
?>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f4f6f9;
}

.main-content{
    margin-left:250px;
    margin-top:85px;
    padding:20px;
}

.card-box{
    border-radius:15px;
    padding:20px;
    color:#fff;
    box-shadow:0 4px 15px rgba(0,0,0,.12);
    transition:.3s;
}

.card-box:hover{
    transform:translateY(-5px);
}

.bg-blue{
    background:linear-gradient(135deg,#2563eb,#1e40af);
}

.bg-green{
    background:linear-gradient(135deg,#16a34a,#15803d);
}

.bg-orange{
    background:linear-gradient(135deg,#f97316,#ea580c);
}

.bg-red{
    background:linear-gradient(135deg,#dc2626,#b91c1c);
}

.bg-purple{
    background:linear-gradient(135deg,#9333ea,#7e22ce);
}

.bg-cyan{
    background:linear-gradient(135deg,#0891b2,#0e7490);
}

.bg-pink{
    background:linear-gradient(135deg,#db2777,#be185d);
}

.bg-dark{
    background:linear-gradient(135deg,#374151,#111827);
}

.card-title{
    color:#fff;
    font-size:14px;
    text-transform:uppercase;
}

.card-value{
    font-size:30px;
    font-weight:bold;
    margin-top:10px;
}

.box{
    background:#fff;
    border-radius:15px;
    padding:20px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
}

.box-title{
    font-size:18px;
    font-weight:600;
    margin-bottom:15px;
}

.status{
    display:flex;
    align-items:center;
    margin-bottom:12px;
}

.dot{
    width:12px;
    height:12px;
    background:#22c55e;
    border-radius:50%;
    margin-right:10px;
}
.card{
    border-radius:15px;
}

.card-body{
    min-height:110px;
}

.card h2,
.card h3,
.card h4{
    font-weight:700;
}

.progress-ring{
    width:220px;
    height:220px;
    position:relative;
    margin:auto;
}

.progress-text{
    position:absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    font-size:40px;
    font-weight:700;
    color:#27b3ff;
}
</style>
<div class="main-content">
<div class="row align-items-center text-center mb-4"> 
    <div class="col-md-4">
        <h4 class="text-black">Collection</h4>
        <h2 class="text-black">
            ৳<?= number_format($total_collection); ?>
        </h2>
    </div>

    <div class="col-md-4 text-center">

        <svg width="180" height="180">

            <circle
                cx="90"
                cy="90"
                r="70"
                stroke="#2b3d6b"
                stroke-width="12"
                fill="none">
            </circle>

            <circle
                cx="90"
                cy="90"
                r="70"
                stroke="#27b3ff"
                stroke-width="12"
                fill="none"
                stroke-linecap="round"
                stroke-dasharray="<?= 2 * pi() * 70 ?>"
                stroke-dashoffset="<?= (2 * pi() * 70) - (($percent / 100) * (2 * pi() * 70)) ?>"
                transform="rotate(-90 90 90)">
            </circle>

            <text
                x="90"
                y="100"
                text-anchor="middle"
                font-size="32"
                font-weight="bold"
                fill="#27b3ff">
                <?= $percent ?>%
            </text>

        </svg>

    </div>

 <div class="col-md-4">
        <h4 class="text-black">Expected</h4>
        <h2 class="text-black">
            ৳<?= number_format($total_bill); ?>
        </h2>
    </div>

</div>
<!-- TOP CARDS -->

<div class="row">

<div class="col-md-3 mb-3">
<div class="card bg-primary text-white shadow">
<div class="card-body">
<h6>Total Customer</h6>
<h2><?= $total_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-success text-white shadow">
<div class="card-body">
<h6>Active Customer</h6>
<h2><?= $active_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-danger text-white shadow">
<div class="card-body">
<h6>Inactive Customer</h6>
<h2><?= $inactive_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-warning shadow">
<div class="card-body">
<h6>Expired Customer</h6>
<h2><?= $expired_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-info text-white shadow">
<div class="card-body">
<h6>Paid Customer</h6>
<h2><?= $paid_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-secondary text-white shadow">
<div class="card-body">
<h6>Unpaid Customer</h6>
<h2><?= $unpaid_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card text-white shadow"
style="background:#6f42c1">
<div class="card-body">
<h6>Free Customer</h6>
<h2><?= $free_customer ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card text-white shadow"
style="background:#198754">
<div class="card-body">
<h6>Total Bill</h6>
<h2>৳<?= number_format($total_bill) ?></h2>
</div>
</div>
</div>

</div>

<!-- COLLECTION -->

<div class="row">

<div class="col-md-3 mb-3">
<div class="card bg-success text-white shadow">
<div class="card-body">
<h6>Total Collection</h6>
<h2>৳<?= number_format($total_collection) ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-primary text-white shadow">
<div class="card-body">
<h6>Today's Collection</h6>
<h2>৳<?= number_format($today_collection) ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-dark text-white shadow">
<div class="card-body">
<h6>Total Connection Fee</h6>
<h2>৳<?= number_format($connection_fee) ?></h2>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-warning shadow">
<div class="card-body">
<h6>Total Discount</h6>
<h2>৳<?= number_format($total_discount) ?></h2>
</div>
</div>
</div>

</div>

<!-- EXPENSE -->

<div class="row">

<div class="col-md-4 mb-3">

<div class="card bg-danger text-white shadow">
<div class="card-body">
<h6>Total Expenditure</h6>
<h2>৳<?= number_format($total_expense) ?></h2>
</div>
</div>

</div>

<div class="col-md-4 mb-3">

<div class="card text-white shadow"
style="background:#0d6efd">
<div class="card-body">
<h6>Total Salary</h6>
<h2>৳<?= number_format($total_salary) ?></h2>
</div>
</div>

</div>

<div class="col-md-4 mb-3">

<div class="card text-white shadow"
style="background:#198754">
<div class="card-body">
<h6>Business Balance</h6>
<h2>৳<?= number_format($business_balance) ?></h2>
</div>
</div>

</div>

</div>


<<!-- MIKROTIK -->

<div class="card shadow mt-3">

<div class="card-header bg-success text-white">
📡 MikroTik Monitoring
</div>

<div class="card-body">

<div class="row">

<div class="col-md-4">
<div class="card text-white shadow"
style="background:linear-gradient(90deg,#0099ff,#00c6ff)">
<div class="card-body d-flex justify-content-between">
<div>
<h6>Total Customer</h6>
<h3><?= $total_customer ?></h3>
</div>
<i class="fa fa-users fa-2x"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card text-white shadow"
style="background:linear-gradient(90deg,#22c55e,#84cc16)">
<div class="card-body d-flex justify-content-between">
<div>
<h6>Online</h6>
<h3><?= $online_user ?></h3>
</div>
<i class="fa fa-wifi fa-2x"></i>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card text-white shadow"
style="background:linear-gradient(90deg,#ef4444,#f97316)">
<div class="card-body d-flex justify-content-between">
<div>
<h6>Offline</h6>
<h3><?= $offline_user ?></h3>
</div>
<i class="fa fa-user-slash fa-2x"></i>
</div>
</div>
</div>



<div class="card shadow mt-3">
<div class="card-header bg-primary text-white">
Monthly Collection Graph
</div>

<div class="card-body">

<canvas id="collectionChart"></canvas>

</div>

</div>

</div>



<!-- ADMIN SUMMARY -->

<div class="card shadow mt-4">

<div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">

<h5 class="mb-0">
👨‍💼 Admin Summary
</h5>

<button
class="btn btn-light btn-sm"
data-bs-toggle="collapse"
data-bs-target="#adminSummary">

<i class="fa fa-angle-down"></i>

</button>

</div>

<div class="collapse" id="adminSummary">

<div class="card-body">

<div class="row">

<div class="col-md-3 mb-3">
<div class="card bg-success text-white">
<div class="card-body">
<h6>Total Collection</h6>
<h4>৳<?= number_format($total_collection) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-primary text-white">
<div class="card-body">
<h6>Connection Fee</h6>
<h4>৳<?= number_format($connection_fee) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-danger text-white">
<div class="card-body">
<h6>Expenditure</h6>
<h4>৳<?= number_format($total_expense) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-warning">
<div class="card-body">
<h6>Discount</h6>
<h4>৳<?= number_format($total_discount) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-info text-white">
<div class="card-body">
<h6>Salary</h6>
<h4>৳<?= number_format($total_salary) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-secondary text-white">
<div class="card-body">
<h6>Deposit</h6>
<h4>৳<?= number_format($deposit_collection) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-dark text-white">
<div class="card-body">
<h6>Own Balance</h6>
<h4>৳<?= number_format($business_balance) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-primary text-white">
<div class="card-body">
<h6>Messages</h6>
<h4><?= $total_message ?></h4>
</div>
</div>
</div>

</div>

</div>

</div>

</div>

<!-- COLLECTOR SUMMARY -->

<div class="card shadow mt-3">

<div class="card-header bg-success text-white d-flex justify-content-between align-items-center">

<h5 class="mb-0">
💰 Collector Summary
</h5>

<button
class="btn btn-light btn-sm"
data-bs-toggle="collapse"
data-bs-target="#collectorSummary">

<i class="fa fa-angle-down"></i>

</button>

</div>

<div class="collapse" id="collectorSummary">

<div class="card-body">

<div class="row">

<div class="col-md-3 mb-3">
<div class="card bg-success text-white">
<div class="card-body">
<h6>All Collector</h6>
<h4><?= $all_collector ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-primary text-white">
<div class="card-body">
<h6>Connection Fee</h6>
<h4>৳<?= number_format($collector_connection_fee) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-warning">
<div class="card-body">
<h6>Deposit</h6>
<h4>৳<?= number_format($collector_deposit) ?></h4>
</div>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card bg-danger text-white">
<div class="card-body">
<h6>Expenditure</h6>
<h4>৳<?= number_format($collector_expense) ?></h4>
</div>
</div>
</div>

<div class="col-md-12">
<div class="card bg-dark text-white">
<div class="card-body text-center">
<h5>Collector Balance</h5>
<h2>৳<?= number_format($collector_balance) ?></h2>
</div>
</div>
</div>

</div>

</div>

</div>

</div>

</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
new Chart(document.getElementById('collectionChart'),{
type:'bar',
data:{
labels:['Jan','Feb','Mar','Apr','May','Jun'],
datasets:[{
label:'Collection',
data:[12000,19000,15000,22000,25000,28000]
}]
}
});
</script>
<?php include 'includes/footer.php'; ?>