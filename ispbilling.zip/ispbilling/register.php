<?php
include "config/db.php";

$msg = "";
if(isset($_POST['register'])){
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // সিকিউরিটির জন্য হ্যাশ করুন

    // ১. ইউজার ডাটাবেসে সেভ করুন
    $insert = mysqli_query($conn, "INSERT INTO users(fullname, username, password) VALUES('$fullname', '$username', '$password')");
    
    if($insert){
        // ২. সদ্য ইনসার্ট হওয়া আইডিটি ধরুন
        $last_id = mysqli_insert_id($conn);
        // ৩. কাস্টমার আইডি তৈরি করুন (যেমন: ISP-10001)
        $customer_id = "ISP-" . (10000 + $last_id);
        
        // ৪. ইউজার টেবিলে আইডিটি আপডেট করুন
        mysqli_query($conn, "UPDATE users SET customer_id='$customer_id' WHERE id='$last_id'");
        
        $msg = "রেজিস্ট্রেশন সফল! আপনার আইডি: $customer_id";
    }
}
?>
<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>ISP Billing Registration</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f5f6fa;
}

.logo{
    max-height:70px;
}

.register-card{
    background:#fff;
    border-radius:15px;
    padding:25px;
    box-shadow:0 2px 15px rgba(0,0,0,.08);
}

.btn-register{
    background:#4fa18c;
    color:#fff;
    border:none;
    height:50px;
    font-size:18px;
    font-weight:600;
}

.btn-register:hover{
    background:#438c79;
    color:#fff;
}

.package-box{
    background:#4fa18c;
    color:#fff;
    border-radius:10px;
    padding:12px;
    text-align:center;
    font-weight:bold;
}

</style>

</head>
<body>

<div class="container py-4">

<div class="row justify-content-center">

<div class="col-lg-8">

<div class="text-center mb-4">

    <h2 class="fw-bold text-success">
        ISP Billing Registration
    </h2>

</div>

<div class="register-card">

<?= $msg ?>

<form method="post">

<div class="mb-3">
<label>প্রতিষ্ঠানের নাম</label>
<input type="text" name="fullname" class="form-control" required>
</div>

<div class="mb-3">
<label>মোবাইল</label>
<input type="text" name="mobile" class="form-control">
</div>

<div class="mb-3">
<label>ই-মেইল</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>ইউজারনেম</label>
<input type="text" name="username" class="form-control" required>
</div>

<div class="mb-3">
<label>পাসওয়ার্ড</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="mb-3">
<label>প্যাকেজ নির্বাচন</label>
<select class="form-select">
    <option>Starter Package</option>
    <option>Professional Package</option>
    <option>Enterprise Package</option>
</select>
</div>

<div class="package-box mb-3">
গ্রাহক : 0 | সাইন আপ ফি : 0 | মাসিক ফি : 0
</div>

<div class="mb-3">
<label>গ্রাহক ধরন</label>

<div class="d-flex gap-4 mt-2">

<label>
<input type="radio" checked>
 PPPoE
</label>

<label>
<input type="radio">
 Static
</label>

<label>
<input type="radio">
 Hotspot
</label>

</div>

</div>

<div class="card p-3 mb-3">

<h5>রেফারেন্স তথ্য</h5>

<div class="mb-2">
<input type="text" class="form-control" placeholder="রেফারেন্স নাম">
</div>

<div>
<input type="text" class="form-control" placeholder="রেফারেন্স মোবাইল">
</div>

</div>

<button type="submit"
        name="register"
        class="btn btn-register w-100">
        রেজিস্টার
</button>

<div class="text-center mt-3">

Already have account?

<a href="login.php">
Login
</a>

</div>

</form>

</div>

</div>

</div>

</div>

</body>
</html>