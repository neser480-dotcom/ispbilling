<?php
include '../includes/auth.php';
include '../config/db.php';

$id = (int)$_GET['id'];

$query = mysqli_query($conn,"
SELECT b.*, c.*
FROM billings b
LEFT JOIN customers c ON b.customer_id = c.id
WHERE b.id = '$id'
");

$data = mysqli_fetch_assoc($query);

$settings = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM settings LIMIT 1")
);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
background:#f4f6f9;
}

.invoice{
background:#fff;
padding:30px;
margin:20px auto;
max-width:800px;
border:1px solid #ddd;
}

@media print{
.no-print{
display:none;
}
}
</style>

</head>
<body>

<div class="invoice">

<div class="text-center">

<?php if(!empty($settings['logo'])){ ?>
<img src="../uploads/logo/<?= $settings['logo'] ?>"
height="80">
<?php } ?>

<h2><?= $settings['company_name'] ?></h2>

<p>
<?= $settings['phone'] ?><br>
<?= $settings['email'] ?><br>
<?= $settings['company_address'] ?>
</p>

</div>

<hr>

<h4>Customer Information</h4>

<table class="table table-bordered">

<tr>
<th>Customer ID</th>
<td><?= $data['customer_id'] ?></td>
</tr>

<tr>
<th>Name</th>
<td><?= $data['name'] ?></td>
</tr>

<tr>
<th>Phone</th>
<td><?= $data['phone'] ?></td>
</tr>

<tr>
<th>Address</th>
<td><?= $data['address'] ?></td>
</tr>

</table>

<h4>Billing Information</h4>

<table class="table table-bordered">

<tr>
<th>Bill ID</th>
<td><?= $data['id'] ?></td>
</tr>

<tr>
<th>Billing Month</th>
<td><?= $data['billing_month'] ?></td>
</tr>

<tr>
<th>Amount</th>
<td><?= $data['amount'] ?> Tk</td>
</tr>

<tr>
<th>Due Amount</th>
<td><?= $data['due_amount'] ?> Tk</td>
</tr>

<tr>
<th>Status</th>
<td><?= $data['status'] ?></td>
</tr>

<tr>
<th>Date</th>
<td><?= $data['created_at'] ?></td>
</tr>

</table>

<div class="text-center mt-4 no-print">

<button onclick="window.print()"
class="btn btn-primary">
Print Invoice
</button>

</div>

</div>

</body>
</html>