<?php
include '../config/db.php';

$id = $_GET['id'];

$data = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM mikrotik_servers WHERE id='$id'")
);

require '../mikrotik/routeros_api.class.php';

$API = new RouterosAPI();

if($API->connect(
    $data['ip'],
    $data['username'],
    $data['password'],
    $data['port']
)){
    echo "<span style='color:green;'>Connected ✔</span>";
    $API->disconnect();
}else{
    echo "<span style='color:red;'>Failed ✖</span>";
}
?>