<?php
include '../config/db.php';
require_once "../mikrotik/routeros_api.class.php";

$id = $_GET['id'];

$row = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM mikrotik_servers WHERE id=$id")
);

$API = new RouterosAPI();
$API->debug = false;

$status = "Disconnected";
$total = 0;
$active = 0;

if($API->connect($row['ip'],$row['username'],$row['password'],$row['port'])){

    $status = "Connected";

    $total = count($API->comm("/ppp/secret/print"));
    $active = count($API->comm("/ppp/active/print"));

    $API->disconnect();
}

include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>🌐 MikroTik Live Panel</h4>

        <a href="index.php" class="btn btn-dark">
            ← Back
        </a>
    </div>

    <div class="row g-4">

        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-primary text-white">
                <div class="card-body">
                    <h6>Connection Status</h6>
                    <h2><?= $status ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-success text-white">
                <div class="card-body">
                    <h6>Total PPPoE Users</h6>
                    <h2><?= $total ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-warning text-dark">
                <div class="card-body">
                    <h6>Active Users</h6>
                    <h2><?= $active ?></h2>
                </div>
            </div>
        </div>

    </div>

    <div class="card border-0 shadow-sm mt-4">

        <div class="card-header bg-dark text-white">
            Router Information
        </div>

        <div class="card-body">

            <table class="table table-bordered">

                <tr>
                    <th width="200">Router Name</th>
                    <td><?= $row['name']; ?></td>
                </tr>

                <tr>
                    <th>IP Address</th>
                    <td><?= $row['ip']; ?></td>
                </tr>

                <tr>
                    <th>Username</th>
                    <td><?= $row['username']; ?></td>
                </tr>

                <tr>
                    <th>API Port</th>
                    <td><?= $row['port']; ?></td>
                </tr>

            </table>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>