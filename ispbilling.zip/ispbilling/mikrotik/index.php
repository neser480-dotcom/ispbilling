<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

<!-- TOP HEADER -->
<div class="d-flex justify-content-between align-items-center mb-3">

<h4>
Total MikroTik Servers:
<?php
echo mysqli_num_rows(mysqli_query($conn,"SELECT * FROM mikrotik_servers"));
?>
</h4>

<div>
<div class="d-flex justify-content-between align-items-center mb-3">

    <h4>MikroTik Management</h4>

</div>
<a href="add.php" class="btn btn-primary btn-sm">+ Add Server</a>
<button class="btn btn-success btn-sm">🔄 Refresh</button>
<a href="tutorial.php" class="btn btn-info btn-sm">📘 Tutorial</a>
</div>

</div>

<!-- SEARCH -->
<form method="GET" class="mb-3">

<div class="input-group">

<input type="text"
       name="search"
       class="form-control"
       placeholder="Search MikroTik (name, IP, user, port)">

<button class="btn btn-dark">Search</button>

</div>

</form>

<!-- TABLE -->
<div class="card shadow-sm border-0">

<div class="card-body">

<table class="table table-hover align-middle">

<thead class="table-dark">
<tr>
<th>#</th>
<th>Name</th>
<th>IP / Host</th>
<th>User</th>
<th>Port</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php
$data = mysqli_query($conn,"SELECT * FROM mikrotik_servers");

$i = 1;
while($row = mysqli_fetch_assoc($data)){
?>

<tr>
<td><?= $i++ ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['ip'] ?></td>
<td><?= $row['username'] ?></td>
<td><?= $row['port'] ?></td>

<td>

<a href="config.php?id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">⚙ Config</a>

<a href="check.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">🔌 Check</a>

<a href="history.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm">📜 History</a>

<a href="../mikrotik/delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">❌ Delete</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>