<?php
include '../config/db.php';

if(isset($_POST['save'])){

    mysqli_query($conn,"INSERT INTO mikrotik_servers
    (name,ip,username,password,port)
    VALUES(
    '{$_POST['name']}',
    '{$_POST['ip']}',
    '{$_POST['username']}',
    '{$_POST['password']}',
    '{$_POST['port']}'
    )");

    header("Location: index.php");
    exit;
}

include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

    <div class="card border-0 shadow-sm">

        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">
                🌐 Add MikroTik Server
            </h5>
        </div>

        <div class="card-body">

            <form method="post">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">
                            Server Name
                        </label>

                        <input
                            type="text"
                            name="name"
                            class="form-control"
                            required
                        >
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">
                            IP Address
                        </label>

                        <input
                            type="text"
                            name="ip"
                            class="form-control"
                            placeholder="192.168.1.1"
                            required
                        >
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">
                            Username
                        </label>

                        <input
                            type="text"
                            name="username"
                            class="form-control"
                            required
                        >
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">
                            Password
                        </label>

                        <input
                            type="password"
                            name="password"
                            class="form-control"
                            required
                        >
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">
                            API Port
                        </label>

                        <input
                            type="number"
                            name="port"
                            value="8728"
                            class="form-control"
                        >
                    </div>

                </div>

                <hr>

                <button
                    type="submit"
                    name="save"
                    class="btn btn-primary"
                >
                    💾 Save Server
                </button>

                <a
                    href="index.php"
                    class="btn btn-secondary"
                >
                    ← Back
                </a>

            </form>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>