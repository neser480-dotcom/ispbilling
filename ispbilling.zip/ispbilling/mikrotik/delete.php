<?php
include '../config/db.php';

if(isset($_GET['id'])){

    $id = (int)$_GET['id'];

    $sql = "DELETE FROM mikrotik_servers WHERE id='$id'";

    if(mysqli_query($conn,$sql)){
        header("Location: index.php");
        exit;
    }else{
        echo "Error: " . mysqli_error($conn);
    }

}else{
    echo "No ID found";
}
?>