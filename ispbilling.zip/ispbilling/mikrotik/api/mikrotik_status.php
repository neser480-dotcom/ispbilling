<?php
header('Content-Type: application/json');

// demo data (replace with MikroTik API later)
echo json_encode([
    "cpu" => rand(10,80),
    "ram" => rand(20,90),
    "uptime" => "5d 3h 22m",
    "traffic" => "120 Mbps"
]);