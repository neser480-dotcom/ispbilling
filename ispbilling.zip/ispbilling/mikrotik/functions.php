<?php

require_once __DIR__ . "/routeros_api.class.php";

/*
|--------------------------------------------------------------------------
| Enable PPPoE User
|--------------------------------------------------------------------------
*/

function mikrotik_enable($server, $username)
{
    $API = new RouterosAPI();
    $API->debug = false;

    if (
        $API->connect(
            $server['ip'],
            $server['username'],
            $server['password'],
            $server['port']
        )
    ) {

        $secret = $API->comm('/ppp/secret/print', [
            '?name' => $username
        ]);

        if (!empty($secret)) {

            $API->comm('/ppp/secret/set', [
                '.id' => $secret[0]['.id'],
                'disabled' => 'false'
            ]);
        }

        $API->disconnect();
    }
}

/*
|--------------------------------------------------------------------------
| Disable PPPoE User
|--------------------------------------------------------------------------
*/

function mikrotik_disable($server, $username)
{
    $API = new RouterosAPI();
    $API->debug = false;

    if (
        $API->connect(
            $server['ip'],
            $server['username'],
            $server['password'],
            $server['port']
        )
    ) {

        $secret = $API->comm('/ppp/secret/print', [
            '?name' => $username
        ]);

        if (!empty($secret)) {

            $API->comm('/ppp/secret/set', [
                '.id' => $secret[0]['.id'],
                'disabled' => 'true'
            ]);
        }

        $API->disconnect();
    }
}

/*
|--------------------------------------------------------------------------
| Check Router Connection
|--------------------------------------------------------------------------
*/

function mikrotik_connect_test($server)
{
    $API = new RouterosAPI();
    $API->debug = false;

    if (
        $API->connect(
            $server['ip'],
            $server['username'],
            $server['password'],
            $server['port']
        )
    ) {

        $API->disconnect();
        return true;
    }

    return false;
}

/*
|--------------------------------------------------------------------------
| Total PPPoE User
|--------------------------------------------------------------------------
*/

function mikrotik_total_user($server)
{
    $API = new RouterosAPI();
    $API->debug = false;

    $total = 0;

    if (
        $API->connect(
            $server['ip'],
            $server['username'],
            $server['password'],
            $server['port']
        )
    ) {

        $total = count(
            $API->comm('/ppp/secret/print')
        );

        $API->disconnect();
    }

    return $total;
}

/*
|--------------------------------------------------------------------------
| Active PPPoE User
|--------------------------------------------------------------------------
*/

function mikrotik_active_user($server)
{
    $API = new RouterosAPI();
    $API->debug = false;

    $active = 0;

    if (
        $API->connect(
            $server['ip'],
            $server['username'],
            $server['password'],
            $server['port']
        )
    ) {

        $active = count(
            $API->comm('/ppp/active/print')
        );

        $API->disconnect();
    }

    return $active;
}

?>