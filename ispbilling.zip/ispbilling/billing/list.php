<?php

include '../includes/auth.php';
include '../config/db.php';

$data = mysqli_query($conn,"
SELECT
billings.*,
customers.customer_id,
customers.name
FROM billings
LEFT JOIN customers
ON customers.id=billings.customer_id
ORDER BY billings.id DESC
");

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-primary text-white">
Billing List
</div>

<div class="card-body">

<table class="table table-bordered table-striped">

<thead>

<tr>
<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Month</th>
<th>Amount</th>
<th>Due</th>
<th>Status</th>
<th>Action</th>
</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>
<td><?= $row['customer_id'] ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['billing_month'] ?></td>
<td><?= $row['amount'] ?></td>
<td><?= $row['due_amount'] ?></td>

<td>

<?php

if($row['status']=="Paid")
{
    echo "<span class='badge bg-success'>Paid</span>";
}
elseif($row['status']=="Partial")
{
    echo "<span class='badge bg-warning'>Partial</span>";
}
else
{
    echo "<span class='badge bg-danger'>Unpaid</span>";
}

?>

</td>

<td>

<a href="details.php?id=<?= $row['id'] ?>"
class="btn btn-info btn-sm">
Details
</a>

<a href="../invoice/invoice.php?id=<?= $row['id'] ?>"
class="btn btn-sm btn-success"
target="_blank">
Print
</a>

<a href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Bill?')">
Delete
</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include '../includes/footer.php'; ?>