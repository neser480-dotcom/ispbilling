<?php

include '../includes/auth.php';
include '../config/db.php';

$month = date('Y-m');

$customers = mysqli_query($conn,"
SELECT * FROM customers
WHERE status='Active'
");

$count = 0;

while($row = mysqli_fetch_assoc($customers))
{
    $check = mysqli_query($conn,"
    SELECT * FROM billings
    WHERE customer_id='".$row['id']."'
    AND billing_month='$month'
    ");

    if(mysqli_num_rows($check)==0)
    {
        mysqli_query($conn,"
        INSERT INTO billings
        (
            customer_id,
            billing_month,
            amount,
            due_amount,
            status
        )
        VALUES
        (
            '".$row['id']."',
            '$month',
            '".$row['monthly_bill']."',
            '".$row['monthly_bill']."',
            'Unpaid'
        )
        ");

        $count++;
    }
}

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">
<div class="card-header bg-success text-white">
Generate Monthly Bill
</div>

<div class="card-body">

<h4><?= $count ?> Bills Generated Successfully</h4>

<a href="list.php" class="btn btn-primary">
Billing List
</a>

</div>
</div>

<?php include '../includes/footer.php'; ?>