<?php

include '../includes/auth.php';
include '../config/db.php';

$id = intval($_GET['id']);

$data = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT
billings.*,
customers.customer_id,
customers.name,
customers.phone
FROM billings
LEFT JOIN customers
ON customers.id=billings.customer_id
WHERE billings.id='$id'
")
);

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-info text-white">
Bill Details
</div>

<div class="card-body">

<table class="table table-bordered">

<tr>
<th>Customer ID</th>
<td><?= $data['customer_id'] ?></td>
</tr>

<tr>
<th>Name</th>
<td><?= $data['name'] ?></td>
</tr>

<tr>
<th>Phone</th>
<td><?= $data['phone'] ?></td>
</tr>

<tr>
<th>Billing Month</th>
<td><?= $data['billing_month'] ?></td>
</tr>

<tr>
<th>Amount</th>
<td><?= $data['amount'] ?> ৳</td>
</tr>

<tr>
<th>Due Amount</th>
<td><?= $data['due_amount'] ?> ৳</td>
</tr>

<tr>
<th>Status</th>
<td><?= $data['status'] ?></td>
</tr>

</table>

<a href="list.php"
class="btn btn-secondary">
Back
</a>

</div>

</div>

<?php include '../includes/footer.php'; ?>