<?php
include '../config/db.php';
require_once __DIR__ . '../mikrotik/routeros_api.class.php';

$rows = mysqli_query($conn,"SELECT * FROM olt");

while($r = mysqli_fetch_assoc($rows)){

    $olt = new OLT();

    if($olt->connect($r['ip'],$r['username'],$r['password'],$r['port'])){

        mysqli_query($conn,"
            UPDATE olt SET status=1,last_seen=NOW()
            WHERE id={$r['id']}
        ");

        mysqli_query($conn,"
            INSERT INTO olt_logs(olt_id,action,message)
            VALUES({$r['id']},'ONLINE','Bulk check success')
        ");

        $olt->disconnect();

    }else{

        mysqli_query($conn,"
            UPDATE olt SET status=0
            WHERE id={$r['id']}
        ");
    }
}

echo "DONE";
?>