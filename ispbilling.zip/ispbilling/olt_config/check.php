<?php
include '../config/db.php';
require_once __DIR__ . '../mikrotik/routeros_api.class.php';

$id = (int)$_GET['id'];

$row = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT * FROM olt WHERE id=$id")
);

if(!$row){
    die("OLT Not Found");
}

$olt = new OLT();

if($olt->connect($row['ip'],$row['username'],$row['password'],$row['port'])){

    // UPDATE STATUS
    mysqli_query($conn,"
        UPDATE olt 
        SET status=1,
            last_seen=NOW()
        WHERE id=$id
    ");

    // LOG
    mysqli_query($conn,"
        INSERT INTO olt_logs(olt_id,action,message)
        VALUES($id,'ONLINE','OLT Connected Successfully')
    ");

    echo "<span class='badge bg-success'>🟢 Online</span>";

    $olt->disconnect();

}else{

    // UPDATE STATUS OFFLINE
    mysqli_query($conn,"
        UPDATE olt 
        SET status=0
        WHERE id=$id
    ");

    // LOG
    mysqli_query($conn,"
        INSERT INTO olt_logs(olt_id,action,message)
        VALUES($id,'OFFLINE','Connection Failed')
    ");

    echo "<span class='badge bg-danger'>🔴 Offline</span>";
}
?>