<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>📡 ONU Signal Status</h4>

        <a href="sync.php" class="btn btn-success">
            Refresh Signal
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">

            <table class="table table-bordered table-hover">

                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>ONU Name</th>
                        <th>Serial</th>
                        <th>RX Power</th>
                        <th>TX Power</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $data = mysqli_query($conn,"SELECT * FROM olt_user");

                while($row = mysqli_fetch_assoc($data)){
                ?>

                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['onu_name']; ?></td>
                    <td><?= $row['onu_sn']; ?></td>
                    <td><?= $row['rx_power']; ?></td>
                    <td><?= $row['tx_power']; ?></td>

                    <td>
                        <?php if($row['status']=='Online'){ ?>
                            <span class="badge bg-success">Online</span>
                        <?php } else { ?>
                            <span class="badge bg-danger">Offline</span>
                        <?php } ?>
                    </td>
                </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>
    </div>

</div>

<?php include '../includes/footer.php'; ?>