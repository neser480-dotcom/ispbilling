<?php
include '../config/db.php';

if(isset($_POST['save'])){

    $olt_name = $_POST['olt_name'];
    $olt_ip = $_POST['olt_ip'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "INSERT INTO olt (name, ip, username, password, status)
            VALUES ('$olt_name', '$olt_ip', '$username', '$password', 1)";

    if(mysqli_query($conn, $sql)){
        header("Location: list.php");
        exit;
    }else{
        echo "DB ERROR: " . mysqli_error($conn);
    }
}

include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h4>📡 Add OLT</h4>

        <a href="list.php" class="btn btn-secondary">
            ← Back To OLT List
        </a>

    </div>

    <div class="card shadow-sm border-0">

        <div class="card-body">

            <form method="post">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">OLT Name</label>
                        <input type="text" name="olt_name" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">OLT IP Address</label>
                        <input type="text" name="olt_ip" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control">
                    </div>

                </div>

               <button type="submit" name="save" class="btn btn-success">
    💾 Save OLT
</button>

                <a href="list.php" class="btn btn-dark">
                    Cancel
                </a>

            </form>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>