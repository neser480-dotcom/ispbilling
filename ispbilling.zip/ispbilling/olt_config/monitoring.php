<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$total_onu   = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM olt_user"));
$online_onu  = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM olt_user WHERE status='Online'"));
$offline_onu = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM olt_user WHERE status='Offline'"));
?>

<div class="main-content">

    <h4 class="mb-4">📡 OLT Monitoring</h4>

    <div class="row">

        <div class="col-md-3">
            <div class="card shadow border-0 bg-primary text-white">
                <div class="card-body text-center">
                    <h6>Total ONU</h6>
                    <h2><?= $total_onu; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow border-0 bg-success text-white">
                <div class="card-body text-center">
                    <h6>Online ONU</h6>
                    <h2><?= $online_onu; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow border-0 bg-danger text-white">
                <div class="card-body text-center">
                    <h6>Offline ONU</h6>
                    <h2><?= $offline_onu; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow border-0 bg-warning text-dark">
                <div class="card-body text-center">
                    <h6>OLT Status</h6>
                    <h2>Online</h2>
                </div>
            </div>
        </div>

    </div>

    <div class="card shadow mt-4 border-0">

        <div class="card-header bg-dark text-white">
            Recent ONU Status
        </div>

        <div class="card-body">

            <table class="table table-bordered table-hover">

                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>ONU Name</th>
                        <th>Serial</th>
                        <th>Status</th>
                        <th>RX Power</th>
                    </tr>
                </thead>

                <tbody>

                <?php
                $data = mysqli_query($conn,"SELECT * FROM olt_user ORDER BY id DESC LIMIT 20");

                while($row = mysqli_fetch_assoc($data)){
                ?>

                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['onu_name']; ?></td>
                    <td><?= $row['onu_sn']; ?></td>

                    <td>
                        <?php if($row['status']=='Online'){ ?>
                            <span class="badge bg-success">Online</span>
                        <?php } else { ?>
                            <span class="badge bg-danger">Offline</span>
                        <?php } ?>
                    </td>

                    <td><?= $row['rx_power']; ?></td>
                </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>