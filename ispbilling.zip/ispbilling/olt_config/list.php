<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$total = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM olt"));
$online = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM olt WHERE status=1"));
$offline = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM olt WHERE status=0"));

$rows = mysqli_query($conn,"SELECT * FROM olt ORDER BY id DESC");
?>

<style>
.net-card{
    border-radius:12px;
    padding:20px;
    color:#fff;
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
}
.net-blue{background:#2f80ed;}
.net-green{background:#27ae60;}
.net-red{background:#eb5757;}
.table-dark-custom{
    background:#1e1e2f;
    color:#fff;
}
.main-content{
    padding:20px;
}
</style>

<div class="main-content">

<!-- TOP CARDS -->
<div class="row mb-4">

    <div class="col-md-4">
        <div class="net-card net-blue text-center">
            <h5>Total OLT</h5>
            <h2><?= $total ?></h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="net-card net-green text-center">
            <h5>Online OLT</h5>
            <h2><?= $online ?></h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="net-card net-red text-center">
            <h5>Offline OLT</h5>
            <h2><?= $offline ?></h2>
        </div>
    </div>

</div>

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-3">

    <h4>📡 OLT Management</h4>

    <div>
        <a href="add.php" class="btn btn-primary btn-sm">+ Add OLT</a>
        <a href="bulk_check.php" class="btn btn-dark btn-sm">🔄 Bulk Check</a>
    </div>

</div>

<!-- SEARCH -->
<form method="GET" class="mb-3">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search OLT...">
        <button class="btn btn-dark">Search</button>
    </div>
</form>

<!-- TABLE -->
<div class="card border-0 shadow-sm">

<div class="card-body p-0">

<table class="table table-hover mb-0">

<thead class="table-dark-custom">
<tr>
    <th>ID</th>
    <th>OLT Name</th>
    <th>IP Address</th>
    <th>User</th>
    <th>Status</th>
    <th>Last Seen</th>
    <th>Action</th>
</tr>
</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($rows)){ ?>

<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['name'] ?></td>
    <td><?= $row['ip'] ?></td>
    <td><?= $row['username'] ?></td>

    <td>
        <?php if($row['status']==1){ ?>
            <span class="badge bg-success">Online</span>
        <?php }else{ ?>
            <span class="badge bg-danger">Offline</span>
        <?php } ?>
    </td>

    <td>
        <?= $row['last_seen'] ?? 'Never' ?>
    </td>

    <td>

        <a href="details.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm">Details</a>

        <a href="check.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">Check</a>

        <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Delete</a>

    </td>

</tr>

<?php } ?>

</tbody>

</table>

</div>
</div>

</div>

<?php include '../includes/footer.php'; ?>