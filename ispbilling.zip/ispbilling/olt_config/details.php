<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$id = $_GET['id'];

$data = mysqli_query($conn,"SELECT * FROM olt WHERE id='$id'");
$row = mysqli_fetch_assoc($data);
?>

<div class="main-content">

    <div class="card shadow">
        <div class="card-header">
            <h4>OLT Details</h4>
        </div>

        <div class="card-body">

            <table class="table table-bordered">

                <tr>
                    <th>ID</th>
                    <td><?= $row['id']; ?></td>
                </tr>

                <tr>
                    <th> Name</th>
                    <td><?= $row['name']; ?></td>
                </tr>

                <tr>
                    <th> IP</th>
                    <td><?= $row['ip']; ?></td>
                </tr>

                <tr>
                    <th>Username</th>
                    <td><?= $row['username']; ?></td>
                </tr>

            </table>

            <a href="list.php" class="btn btn-dark">
                Back
            </a>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>