<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>📡 ONU List</h4>

        <a href="sync.php" class="btn btn-success">
            Sync ONU
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">

            <table class="table table-bordered table-hover">

                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>ONU Name</th>
                        <th>Serial</th>
                        <th>Status</th>
                        <th>RX Power</th>
                    </tr>
                </thead>

                <tbody>

                    <tr>
                        <td>1</td>
                        <td>ONU-01</td>
                        <td>ZTE12345678</td>
                        <td>
                            <span class="badge bg-success">
                                Online
                            </span>
                        </td>
                        <td>-22 dBm</td>
                    </tr>

                </tbody>

            </table>

        </div>
    </div>

</div>

<?php include '../includes/footer.php'; ?>