<?php
require_once __DIR__ . '../mikrotik/routeros_api.class.php';
class OLT {

    public $API;

    function connect($ip,$user,$pass,$port){

        $this->API = new RouterosAPI();

        return $this->API->connect($ip,$user,$pass,$port);
    }

    function disconnect(){
        $this->API->disconnect();
    }

}
?>