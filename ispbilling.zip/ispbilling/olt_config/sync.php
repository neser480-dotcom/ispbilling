<?php

include __DIR__ . "/../config/db.php";

function getOltData() {
    return [
        [
            "olt_id" => 1,
            "onu_name" => "ONU-1",
            "onu_sn" => "SN123456",
            "mac_address" => "AA:BB:CC:DD:EE:01",
            "ip_address" => "192.168.1.10",
            "pon_port" => "PON1/1",
            "rx_power" => -18.5,
            "tx_power" => 2.1,
            "status" => "Online"
        ],
        [
            "olt_id" => 1,
            "onu_name" => "ONU-2",
            "onu_sn" => "SN123457",
            "mac_address" => "AA:BB:CC:DD:EE:02",
            "ip_address" => "192.168.1.11",
            "pon_port" => "PON1/2",
            "rx_power" => -21.0,
            "tx_power" => 2.0,
            "status" => "Offline"
        ]
    ];
}

$data = getOltData();

foreach ($data as $onu) {

    $olt_id = (int)$onu['olt_id'];

    $onu_name = mysqli_real_escape_string($conn, $onu['onu_name']);
    $onu_sn = mysqli_real_escape_string($conn, $onu['onu_sn']);
    $mac_address = mysqli_real_escape_string($conn, $onu['mac_address']);
    $ip_address = mysqli_real_escape_string($conn, $onu['ip_address']);
    $pon_port = mysqli_real_escape_string($conn, $onu['pon_port']);
    $status = mysqli_real_escape_string($conn, $onu['status']);

    $rx_power = (float)$onu['rx_power'];
    $tx_power = (float)$onu['tx_power'];

    // check existing
    $check = mysqli_query($conn, "SELECT id FROM olt_user WHERE onu_sn='$onu_sn' LIMIT 1");

    if(mysqli_num_rows($check) > 0) {

        mysqli_query($conn, "
            UPDATE olt_user SET
                olt_id=$olt_id,
                onu_name='$onu_name',
                mac_address='$mac_address',
                ip_address='$ip_address',
                pon_port='$pon_port',
                rx_power=$rx_power,
                tx_power=$tx_power,
                status='$status',
                last_seen=NOW()
            WHERE onu_sn='$onu_sn'
        ");

    } else {

        mysqli_query($conn, "
            INSERT INTO olt_user (
                olt_id, onu_name, onu_sn, mac_address,
                ip_address, pon_port, rx_power, tx_power, status, last_seen
            ) VALUES (
                $olt_id, '$onu_name', '$onu_sn', '$mac_address',
                '$ip_address', '$pon_port', $rx_power, $tx_power, '$status', NOW()
            )
        ");
    }
}

echo "Sync Completed Successfully!";
?>