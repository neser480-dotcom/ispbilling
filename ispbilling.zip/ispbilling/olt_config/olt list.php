<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h4>📡 OLT Management</h4>

        <div>
            <a href="add.php" class="btn btn-primary">
                + Add OLT
            </a>
        </div>

    </div>

    <div class="card shadow-sm border-0">

        <div class="card-body">

            <table class="table table-bordered table-hover align-middle">

                <thead class="table-dark">

                    <tr>
                        <th>ID</th>
                        <th>OLT Name</th>
                        <th>IP Address</th>
                        <th>Username</th>
                        <th>Status</th>
                        <th width="250">Action</th>
                    </tr>

                </thead>

                <tbody>

                    <?php
                    $data = mysqli_query($conn,"SELECT * FROM olt");

                    while($row = mysqli_fetch_assoc($data)){
                    ?>

                    <tr>

                        <td><?= $row['id']; ?></td>
                        <td><?= $row['olt_name']; ?></td>
                        <td><?= $row['olt_ip']; ?></td>
                        <td><?= $row['username']; ?></td>

                        <td>
                            <span class="badge bg-success">
                                Online
                            </span>
                        </td>

                        <td>

                          <a href="details.php?id=<?= $row['id'] ?>">Details</a>

                            <a href="edit.php?id=<?= $row['id']; ?>"
                               class="btn btn-warning btn-sm">
                               Edit
                            </a>

                            <a href="delete.php?id=<?= $row['id']; ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Delete this OLT?')">
                               Delete
                            </a>

                        </td>

                    </tr>

                    <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>