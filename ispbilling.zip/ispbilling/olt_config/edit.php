<?php
include '../config/db.php';

$id = $_GET['id'];

$data = mysqli_query($conn,"SELECT * FROM olt WHERE id='$id'");
$row = mysqli_fetch_assoc($data);

if(isset($_POST['update'])){

    mysqli_query($conn,"
    UPDATE olt SET
    olt_name='{$_POST['olt_name']}',
    olt_ip='{$_POST['olt_ip']}',
    username='{$_POST['username']}',
    password='{$_POST['password']}'
    WHERE id='$id'
    ");

    header("Location:list.php");
    exit;
}

include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

<div class="card shadow">
<div class="card-body">

<h4>Edit OLT</h4>

<form method="post">

<label>OLT Name</label>
<input type="text" name="olt_name" class="form-control"
value="<?= $row['name']; ?>">

<br>

<label>OLT IP</label>
<input type="text" name="olt_ip" class="form-control"
value="<?= $row['ip']; ?>">

<br>

<label>Username</label>
<input type="text" name="username" class="form-control"
value="<?= $row['username']; ?>">

<br>

<label>Password</label>
<input type="text" name="password" class="form-control"
value="<?= $row['password']; ?>">

<br>

<button type="submit"
name="update"
class="btn btn-primary">
Update OLT
</button>

<a href="list.php"
class="btn btn-secondary">
Back
</a>

</form>

</div>
</div>

</div>