<?php

include '../includes/auth.php';
include '../config/db.php';

$id = intval($_GET['id']);

$data = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT
payments.*,
customers.customer_id,
customers.name,
customers.phone
FROM payments
LEFT JOIN customers
ON customers.id=payments.customer_id
WHERE payments.id='$id'
")
);

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-info text-white">
Payment Details
</div>

<div class="card-body">

<table class="table table-bordered">

<tr>
<th>Customer ID</th>
<td><?= $data['customer_id'] ?></td>
</tr>

<tr>
<th>Name</th>
<td><?= $data['name'] ?></td>
</tr>

<tr>
<th>Phone</th>
<td><?= $data['phone'] ?></td>
</tr>

<tr>
<th>Amount</th>
<td><?= $data['amount'] ?> ৳</td>
</tr>

<tr>
<th>Payment Method</th>
<td><?= $data['payment_method'] ?></td>
</tr>

<tr>
<th>Payment Date</th>
<td><?= $data['payment_date'] ?></td>
</tr>

<tr>
<th>Created At</th>
<td><?= $data['created_at'] ?></td>
</tr>

</table>

<a href="list.php"
class="btn btn-secondary">
Back
</a>

</div>

</div>

<?php include '../includes/footer.php'; ?>