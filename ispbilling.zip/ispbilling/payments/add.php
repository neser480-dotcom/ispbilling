<?php

include '../includes/auth.php';
include '../config/db.php';
include '../mikrotik/functions.php'; // 🔥 ADD THIS

if(isset($_POST['save']))
{
    $billing_id = $_POST['billing_id'];
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];
    $payment_date = $_POST['payment_date'];

    $bill = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT * FROM billings
    WHERE id='$billing_id'
    ")
    );

    $new_due = $bill['due_amount'] - $amount;

    if($new_due <= 0)
    {
        $status = "Paid";
        $new_due = 0;
    }
    else
    {
        $status = "Partial";
    }

    // 1. INSERT PAYMENT
    mysqli_query($conn,"
    INSERT INTO payments
    (
        customer_id,
        amount,
        payment_method,
        payment_date
    )
    VALUES
    (
        '".$bill['customer_id']."',
        '$amount',
        '$payment_method',
        '$payment_date'
    )
    ");

    // 2. UPDATE BILL
    mysqli_query($conn,"
    UPDATE billings
    SET
    due_amount='$new_due',
    status='$status'
    WHERE id='$billing_id'
    ");

    // 🔥 3. MICRO TIK AUTO ENABLE (FINAL ADD)
    $server = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT * FROM mikrotik_servers
    WHERE id='{$bill['mikrotik_id']}'
    "));

    if($server && $bill['ppp_username']){
        mikrotik_enable($server, $bill['ppp_username']);
    }

    header("Location:list.php");
    exit();
}

$bills = mysqli_query($conn,"
SELECT
billings.*,
customers.name
FROM billings
LEFT JOIN customers
ON customers.id=billings.customer_id
WHERE due_amount > 0
");

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-success text-white">
Collect Payment
</div>

<div class="card-body">

<form method="POST">

<label>Select Bill</label>

<select
name="billing_id"
class="form-control mb-3"
required>

<option value="">Select Bill</option>

<?php while($b=mysqli_fetch_assoc($bills)){ ?>

<option value="<?= $b['id'] ?>">
<?= $b['name'] ?> - <?= $b['billing_month'] ?> - Due: <?= $b['due_amount'] ?>
</option>

<?php } ?>

</select>

<label>Amount</label>
<input type="number" name="amount" class="form-control mb-3" required>

<label>Payment Method</label>
<select name="payment_method" class="form-control mb-3">
<option>Cash</option>
<option>bKash</option>
<option>Nagad</option>
<option>Bank</option>
</select>

<label>Payment Date</label>
<input type="date" name="payment_date" class="form-control mb-3" value="<?= date('Y-m-d') ?>">

<button type="submit" name="save" class="btn btn-success">
Save Payment
</button>

</form>

</div>
</div>

<?php include '../includes/footer.php'; ?>