<?php

include '../includes/auth.php';
include '../config/db.php';

$id = intval($_GET['id']);

mysqli_query(
$conn,
"DELETE FROM payments
WHERE id='$id'"
);

header("Location:list.php");
exit();