<?php

include '../includes/auth.php';
include '../config/db.php';

$data = mysqli_query($conn,"
SELECT
payments.*,
customers.customer_id,
customers.name
FROM payments
LEFT JOIN customers
ON customers.id=payments.customer_id
ORDER BY payments.id DESC
");

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-primary text-white">
Payment History
</div>

<div class="card-body">

<a href="add.php"
class="btn btn-success mb-3">
Collect Payment
</a>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Amount</th>
<th>Method</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= $row['customer_id'] ?></td>

<td><?= $row['name'] ?></td>

<td><?= $row['amount'] ?></td>

<td><?= $row['payment_method'] ?></td>

<td><?= $row['payment_date'] ?></td>
<td>

<a href="details.php?id=<?= $row['id'] ?>"
class="btn btn-info btn-sm">
Details
</a>

<a href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Payment?')">
Delete
</a>

</td>
</tr>

<?php } ?>

</table>

</div>

</div>

<?php include '../includes/footer.php'; ?>