<?php
include '../config/db.php';

$id = $_GET['id'];

$data = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT * FROM staff
WHERE id='$id'
")
);

if(isset($_POST['update'])){

    $staff_id  = $_POST['staff_id'];
    $name      = $_POST['name'];
    $mobile    = $_POST['mobile'];
    $email     = $_POST['email'];
    $address   = $_POST['address'];
    $role      = $_POST['role'];
    $salary    = $_POST['salary'];
    $join_date = $_POST['join_date'];
    $status    = $_POST['status'];

    mysqli_query($conn,"
    UPDATE staff SET

    staff_id='$staff_id',
    name='$name',
    mobile='$mobile',
    email='$email',
    address='$address',
    role='$role',
    salary='$salary',
    join_date='$join_date',
    status='$status'

    WHERE id='$id'
    ");

    header("Location:view.php?id=$id");
    exit();
}

include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white"
style="background:linear-gradient(90deg,#ff9800,#ff5722);">

<h5 class="mb-0">
<i class="fa fa-pen"></i>
 Edit Staff
</h5>

</div>

<div class="card-body">

<form method="POST">

<div class="row">

<div class="col-md-6">

<label>Staff ID</label>
<input type="text"
name="staff_id"
class="form-control mb-3"
value="<?= $data['staff_id'] ?>">

<label>Name</label>
<input type="text"
name="name"
class="form-control mb-3"
value="<?= $data['name'] ?>">

<label>Mobile</label>
<input type="text"
name="mobile"
class="form-control mb-3"
value="<?= $data['mobile'] ?>">

<label>Email</label>
<input type="email"
name="email"
class="form-control mb-3"
value="<?= $data['email'] ?>">

</div>

<div class="col-md-6">

<label>Role</label>
<select name="role"
class="form-control mb-3">

<option value="Manager"
<?= $data['role']=='Manager'?'selected':'' ?>>
Manager
</option>

<option value="Collector"
<?= $data['role']=='Collector'?'selected':'' ?>>
Collector
</option>

<option value="Employee"
<?= $data['role']=='Employee'?'selected':'' ?>>
Employee
</option>

</select>

<label>Salary</label>
<input type="number"
name="salary"
class="form-control mb-3"
value="<?= $data['salary'] ?>">

<label>Join Date</label>
<input type="date"
name="join_date"
class="form-control mb-3"
value="<?= $data['join_date'] ?>">

<label>Status</label>
<select name="status"
class="form-control mb-3">

<option value="Active"
<?= $data['status']=='Active'?'selected':'' ?>>
Active
</option>

<option value="Inactive"
<?= $data['status']=='Inactive'?'selected':'' ?>>
Inactive
</option>

</select>

</div>

<div class="col-md-12">

<label>Address</label>
<textarea
name="address"
class="form-control mb-3"
rows="4"><?= $data['address'] ?></textarea>

</div>

</div>

<button
type="submit"
name="update"
class="btn btn-success">

<i class="fa fa-save"></i>
 Update Staff

</button>

<a href="view.php?id=<?= $data['id'] ?>"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>