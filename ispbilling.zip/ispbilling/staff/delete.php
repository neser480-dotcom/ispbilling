<?php
include '../config/db.php';

$id = $_GET['id'];

$data = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT * FROM staff
WHERE id='$id'
")
);

if(!$data){
    die("Staff Not Found");
}

$role = $data['role'];

mysqli_query($conn,"
DELETE FROM staff
WHERE id='$id'
");

if($role=='Manager'){
    header("Location: manager.php");
}
elseif($role=='Collector'){
    header("Location: collector.php");
}
else{
    header("Location: employee.php");
}

exit();
?>