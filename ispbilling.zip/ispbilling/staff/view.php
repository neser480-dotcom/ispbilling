<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$id = $_GET['id'];

$data = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT * FROM staff
WHERE id='$id'
")
);
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white d-flex justify-content-between align-items-center"
style="background:linear-gradient(90deg,#0d6efd,#00c6ff);">

<h5 class="mb-0">
<i class="fa fa-user"></i>
 Staff Profile
</h5>

<a href="javascript:history.back()"
class="btn btn-light btn-sm">
<i class="fa fa-arrow-left"></i>
 Back
</a>

</div>

<div class="card-body">

<div class="text-center mb-4">

<div style="
width:100px;
height:100px;
border-radius:50%;
background:#0d6efd;
color:#fff;
font-size:40px;
display:flex;
align-items:center;
justify-content:center;
margin:auto;">
<?= strtoupper(substr($data['name'],0,1)) ?>
</div>

<h4 class="mt-3">
<?= $data['name'] ?>
</h4>

<span class="badge bg-primary">
<?= $data['role'] ?>
</span>

</div>

<table class="table table-bordered">

<tr>
<th width="250">Staff ID</th>
<td><?= $data['staff_id'] ?></td>
</tr>

<tr>
<th>Name</th>
<td><?= $data['name'] ?></td>
</tr>

<tr>
<th>Mobile</th>
<td><?= $data['mobile'] ?></td>
</tr>

<tr>
<th>Email</th>
<td><?= $data['email'] ?></td>
</tr>

<tr>
<th>Address</th>
<td><?= $data['address'] ?></td>
</tr>

<tr>
<th>Role</th>
<td><?= $data['role'] ?></td>
</tr>

<tr>
<th>Salary</th>
<td>৳<?= number_format($data['salary']) ?></td>
</tr>

<tr>
<th>Join Date</th>
<td><?= $data['join_date'] ?></td>
</tr>

<tr>
<th>Status</th>
<td>
<?php if($data['status']=='Active'){ ?>
<span class="badge bg-success">Active</span>
<?php } else { ?>
<span class="badge bg-danger">Inactive</span>
<?php } ?>
</td>
</tr>

<tr>
<th>Created At</th>
<td><?= $data['created_at'] ?></td>
</tr>

</table>

<div class="mt-3">

<a href="edit.php?id=<?= $data['id'] ?>"
class="btn btn-warning">
<i class="fa fa-pen"></i>
 Edit
</a>

<a href="delete.php?id=<?= $data['id'] ?>"
class="btn btn-danger"
onclick="return confirm('Delete Staff?')">
<i class="fa fa-trash"></i>
 Delete
</a>

</div>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>