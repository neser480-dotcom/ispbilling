<?php
include '../config/db.php';

if(isset($_POST['save'])){

    $staff_id  = $_POST['staff_id'];
    $name      = $_POST['name'];
    $mobile    = $_POST['mobile'];
    $email     = $_POST['email'];
    $address   = $_POST['address'];
    $salary    = $_POST['salary'];
    $join_date = $_POST['join_date'];
    $status    = $_POST['status'];

    mysqli_query($conn,"
    INSERT INTO staff(
        staff_id,
        name,
        mobile,
        email,
        address,
        role,
        salary,
        join_date,
        status
    ) VALUES (
        '$staff_id',
        '$name',
        '$mobile',
        '$email',
        '$address',
        'Manager',
        '$salary',
        '$join_date',
        '$status'
    )
    ");

    header("Location: manager.php");
    exit();
}


include '../includes/sidebar.php';
include '../includes/topbar.php';
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white"
style="background:linear-gradient(90deg,#0d6efd,#00c6ff);">

<h5 class="mb-0">
<i class="fa fa-user-tie"></i>
 Add Manager
</h5>

</div>

<div class="card-body">

<form method="POST">

<div class="row">

<div class="col-md-6">

<label>Staff ID</label>
<input type="text"
name="staff_id"
class="form-control mb-3"
required>

<label>Manager Name</label>
<input type="text"
name="name"
class="form-control mb-3"
required>

<label>Mobile</label>
<input type="text"
name="mobile"
class="form-control mb-3">

<label>Email</label>
<input type="email"
name="email"
class="form-control mb-3">

</div>

<div class="col-md-6">

<label>Salary</label>
<input type="number"
name="salary"
class="form-control mb-3">

<label>Join Date</label>
<input type="date"
name="join_date"
class="form-control mb-3">

<label>Status</label>
<select
name="status"
class="form-control mb-3">

<option value="Active">Active</option>
<option value="Inactive">Inactive</option>

</select>

<label>Address</label>
<textarea
name="address"
class="form-control mb-3"
rows="3"></textarea>

</div>

</div>

<button type="submit"
name="save"
class="btn btn-success">

<i class="fa fa-save"></i>
 Save Manager

</button>

<a href="manager.php"
class="btn btn-secondary">

Back

</a>

</form>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>