<?php
include '../config/db.php';
include '../includes/topbar.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$data = mysqli_query($conn,"
SELECT *
FROM staff
WHERE role='employee'
ORDER BY id DESC
");

$total = mysqli_num_rows($data);
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white d-flex justify-content-between align-items-center"
style="background:linear-gradient(90deg,#0d6efd,#00c6ff);">

<div>
<h5 class="mb-0">
<i class="fa fa-user-tie"></i>
 Manager List
</h5>
</div>

<div>

<a href="add.php"
class="btn btn-light btn-sm">
<i class="fa fa-plus"></i>
 Add Manager
</a>

<a href=""
class="btn btn-light btn-sm">
<i class="fa fa-rotate-right"></i>
</a>

</div>

</div>

<div class="card-body">

<div class="row mb-3">

<div class="col-md-3">

<div class="card border-0 shadow-sm">

<div class="card-body text-center">

<h6>Total Manager</h6>

<h2 class="text-primary">
<?= $total ?>
</h2>

</div>

</div>

</div>

</div>

<div class="table-responsive">

<table class="table table-hover table-bordered align-middle">

<thead class="table-primary">

<tr>
<th>ID</th>
<th>Staff ID</th>
<th>Name</th>
<th>Mobile</th>
<th>Salary</th>
<th>Status</th>
<th width="180">Action</th>
</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td>
<span class="badge bg-dark">
<?= $row['staff_id'] ?>
</span>
</td>

<td>
<b><?= $row['name'] ?></b>
</td>

<td><?= $row['mobile'] ?></td>

<td>
<span class="text-success fw-bold">
৳<?= number_format($row['salary']) ?>
</span>
</td>

<td>

<?php if($row['status']=='Active'){ ?>

<span class="badge bg-success">
Active
</span>

<?php } else { ?>

<span class="badge bg-danger">
Inactive
</span>

<?php } ?>

</td>

<td>

<a href="view.php?id=<?= $row['id'] ?>"
class="btn btn-info btn-sm">
<i class="fa fa-eye"></i>
</a>

<a href="edit.php?id=<?= $row['id'] ?>"
class="btn btn-warning btn-sm">
<i class="fa fa-pen"></i>
</a>

<a href="delete.php?id=<?= $row['id'] ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete Staff?')">
<i class="fa fa-trash"></i>
</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>