<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$data = mysqli_query($conn,"SELECT * FROM activity_logs ORDER BY id DESC");
?>
<div class="main-content">
<div class="container-fluid mt-4">

    <div class="card shadow-lg border-0">

        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">📋 Activity Log</h4>
        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Module</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>Date Time</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php while($row=mysqli_fetch_assoc($data)){ ?>

                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= $row['user_name']; ?></td>
                            <td><?= $row['module_name']; ?></td>
                            <td>

                                <?php
                                if($row['action_type']=='Add'){
                                    echo '<span class="badge bg-success">Add</span>';
                                }
                                elseif($row['action_type']=='Edit'){
                                    echo '<span class="badge bg-warning text-dark">Edit</span>';
                                }
                                elseif($row['action_type']=='Delete'){
                                    echo '<span class="badge bg-danger">Delete</span>';
                                }
                                elseif($row['action_type']=='Collect'){
                                    echo '<span class="badge bg-info">Collect</span>';
                                }
                                else{
                                    echo '<span class="badge bg-secondary">'.$row['action_type'].'</span>';
                                }
                                ?>

                            </td>

                            <td><?= $row['description']; ?></td>

                            <td><?= $row['created_at']; ?></td>
                        </tr>

                    <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>