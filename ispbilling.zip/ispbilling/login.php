<?php
session_start();
include "config/db.php";
$error = "";

if(isset($_POST['login'])){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // ডাটাবেস থেকে ইউজার খুঁজুন
    $sql = "SELECT * FROM users WHERE username='$username' LIMIT 1";
    $res = mysqli_query($conn, $sql);

    if(mysqli_num_rows($res) == 1){
        $user = mysqli_fetch_assoc($res);

        // যেহেতু আপনার পাসওয়ার্ড ডাটাবেসে সাধারণ টেক্সট হিসেবে আছে, 
        // তাই সরাসরি তুলনা (Comparison) করতে হবে:
        if($password == $user['password']){ 
            
            // লগইন সফল হলে সেশন সেট করুন
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['customer_id'] = $user['customer_id']; // যদি কলামটি থাকে
            
            header("Location: dashboard.php");
            exit();
        } else {
            echo "পাসওয়ার্ড ভুল হয়েছে।";
        }
    } else {
        echo "ইউজার খুঁজে পাওয়া যায়নি।";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>NetFee ISP Billing Login</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI',sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0f172a,#2563eb,#06b6d4);
}

.login-box{
    width:420px;
    background:#fff;
    padding:40px;
    border-radius:20px;
    box-shadow:0 15px 40px rgba(0,0,0,.2);
}

.logo{
    text-align:center;
    margin-bottom:25px;
}

.logo h1{
    color:#2563eb;
    font-size:32px;
}

.logo p{
    color:#666;
    font-size:14px;
}

.input-group{
    margin-bottom:15px;
}

.input-group input{
    width:100%;
    padding:14px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:15px;
}

.input-group input:focus{
    outline:none;
    border-color:#2563eb;
}

.login-btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:10px;
    background:#2563eb;
    color:#fff;
    font-size:16px;
    cursor:pointer;
}

.login-btn:hover{
    background:#1d4ed8;
}

.links{
    margin-top:20px;
    display:flex;
    justify-content:space-between;
}

.links a{
    text-decoration:none;
    color:#2563eb;
    font-size:14px;
}

.error{
    color:red;
    text-align:center;
    margin-bottom:10px;
}

.footer{
    text-align:center;
    margin-top:20px;
    color:#999;
    font-size:13px;
}
</style>

</head>
<body>

<div class="login-box">

    <div class="logo">
        <h1>NetFee</h1>
        <p>ISP Billing & Management System</p>
    </div>

    <?php if(!empty($error)){ ?>
        <div class="error"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST">

        <div class="input-group">
            <input type="text" name="username" placeholder="Username" required>
        </div>

        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
        </div>

        <button type="submit" name="login" class="login-btn">
            Login
        </button>

    </form>

    <div class="links">
        <a href="register.php">Create Account</a>
        <a href="forgot.php">Forgot Password?</a>
    </div>

    <div class="footer">
        © <?php echo date('Y'); ?> NetFee ISP Billing System
    </div>

</div>

</body>
</html>