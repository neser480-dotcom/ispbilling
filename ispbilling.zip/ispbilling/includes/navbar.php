<nav class="navbar navbar-expand-lg navbar-dark bg-primary">

<div class="container-fluid">

<a class="navbar-brand" href="#">
ISP Billing System
</a>

<div class="ms-auto">

<span class="text-white me-3">
Welcome, <?= $_SESSION['username'] ?? 'Admin'; ?>
</span>

<a href="logout.php"
style="background:red;color:white;padding:8px 15px;
text-decoration:none;border-radius:5px;">
Logout
</a>



</div>

</div>

</nav>