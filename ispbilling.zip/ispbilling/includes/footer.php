</div> <!-- content -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</div> <!-- content -->
 </div> <!-- main -->
</div> <!-- d-flex -->
<!-- সবশেষে -->
<script>
setInterval(function(){

fetch("api/mikrotik_status.php")
.then(res => res.json())
.then(data => {

    document.getElementById("cpu").innerText = data.cpu + "%";
    document.getElementById("ram").innerText = data.ram + "%";
    document.getElementById("uptime").innerText = data.uptime;
    document.getElementById("traffic").innerText = data.traffic;

    // optional
    document.getElementById("status").innerText = data.status;
    document.getElementById("routerName").innerText = data.name;

});

}, 5000);
</script>
<script>
document.addEventListener("DOMContentLoaded", function(){

    const btn = document.querySelector(".menu-btn");
    const sidebar = document.querySelector(".sidebar");
    const content = document.querySelector(".main-content");

    btn.addEventListener("click", function(){

        sidebar.classList.toggle("hide-sidebar");

        if(content){
            content.classList.toggle("full-content");
        }

    });

});
</script>
<script>
document.addEventListener("DOMContentLoaded", function(){

    const profileBtn = document.getElementById("profileBtn");
    const profileMenu = document.getElementById("profileMenu");

    profileBtn.addEventListener("click", function(e){
        e.stopPropagation();
        profileMenu.classList.toggle("show");
    });

    document.addEventListener("click", function(){
        profileMenu.classList.remove("show");
    });

});
</script>

<div class="modal fade" id="billingCycleModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">
                    Select Billing Cycle Panel
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal">
                </button>
            </div>

            <form action="billing_cycle.php" method="post">

                <div class="modal-body">

                    <div class="form-check mb-3">
                        <input class="form-check-input"
                               type="radio"
                               name="panel"
                               value="admin"
                               checked>

                        <label class="form-check-label">
                            Admin
                        </label>
                    </div>

                    <div class="form-check">
                        <input class="form-check-input"
                               type="radio"
                               name="panel"
                               value="reseller">

                        <label class="form-check-label">
                            Reseller
                        </label>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="submit"
                            class="btn btn-success">
                        Submit
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function(){

    const btn = document.getElementById("themeToggle");

    if(localStorage.getItem("theme") === "dark"){
        document.body.classList.add("dark-mode");
        btn.innerHTML = "☀️";
    }

    btn.addEventListener("click", function(){

        document.body.classList.toggle("dark-mode");

        if(document.body.classList.contains("dark-mode")){
            localStorage.setItem("theme","dark");
            btn.innerHTML = "☀️";
        }else{
            localStorage.setItem("theme","light");
            btn.innerHTML = "🌙";
        }

    });

});
</script>
<script>
document.addEventListener("DOMContentLoaded", function(){

    const btn = document.getElementById("langBtn");
    const menu = document.getElementById("langMenu");

    btn.addEventListener("click", function(e){
        e.stopPropagation();
        menu.classList.toggle("show");
    });

    document.addEventListener("click", function(){
        menu.classList.remove("show");
    });

});
</script>

</body>
</html>