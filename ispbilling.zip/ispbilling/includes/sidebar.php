<div class="sidebar">
    <div class="logo">
    <div class="sidebar-profile" style="padding: 20px; color: #fff;">
    <?php if(isset($_SESSION['fullname'])): ?>
        <h5 style="font-size: 16px; margin: 0;">
            <i class="fa fa-user"></i> <?php echo $_SESSION['fullname']; ?>
        </h5>
        <p style="font-size: 14px; opacity: 0.8; margin: 5px 0 0 0;">
            ID: <?php echo $_SESSION['customer_id']; ?>
        </p>
    <?php else: ?>
        <p>Guest User</p>
    <?php endif; ?>
</div>
    </div>

    <ul>

        <li>
	<a href="/ispbilling/dashboard.php">
		🏠 Dashboard
	     </a>
	</li>

        <li>
   	 <a href="/ispbilling/areas/list.php">
       	 	🌍 Area
   	     </a>
	</li>

        <li>
    <a href="/ispbilling/mikrotik/index.php">
        🌐 mikroTik
    </a>
	</li>

        <li>
            <a data-bs-toggle="collapse" href="#oltMenu">
                📡 olt_config <span>▼</span>
            </a>
            <div class="collapse" id="oltMenu">
                <a href="/ispbilling/olt_config/list.php" class="submenu">OLT List</a>
                <a href="/ispbilling/olt_config/onu.php" class="submenu">ONU List</a>
                <a href="/ispbilling/olt_config/signal.php" class="submenu">Signal Status</a>
            </div>
        </li>

        <li>
            <a data-bs-toggle="collapse" href="#monitorMenu">
                📊 Monitoring <span>▼</span>
            </a>
            <div class="collapse" id="monitorMenu">
               <a href="/ispbilling/monitoring/online.php"class="submenu">Online Customer
		</a>

		<a href="/ispbilling/monitoring/offline.php"class="submenu">Offline Customer
		</a>

		<a href="/ispbilling/monitoring/bandwidth.php"class="submenu">Bandwidth Monitor
		</a>
            </div>
        </li>

       <li>
    <a data-bs-toggle="collapse" href="#customerMenu">
        👥 Customers <span>▼</span>
    </a>

    <div class="collapse" id="customerMenu">

        <a href="/ispbilling/customers/list.php"
           class="submenu">
           PPPoE Customers
        </a>

        <a href="/ispbilling/customers/active_pppoe.php"
           class="submenu">
           Active PPPoE
        </a>

        <a href="/ispbilling/customers/other.php"
           class="submenu">
           Other Customers
        </a>
    </div>
</li>

        <li>
            <a data-bs-toggle="collapse" href="#reportMenu">
                📑 Reports <span>▼</span>
            </a>
            <div class="collapse" id="reportMenu">
                <a href="/ispbilling/reports/collection.php" class="submenu">
		Collection Report
		</a>
                <a href="/ispbilling/reports/due.php" class="submenu">Due Report</a>
            </div>
        </li>

       <li>
    <a data-bs-toggle="collapse" href="#staffMenu">
        👨‍💼 Staff <span>▼</span>
    </a>

    <div class="collapse" id="staffMenu">

        <a href="/ispbilling/staff/manager.php"
           class="submenu">
           Manager
        </a>

        <a href="/ispbilling/staff/collector.php"
           class="submenu">
           Collector
        </a>

        <a href="/ispbilling/staff/employee.php"
           class="submenu">
           Employee
        </a>

    </div>
</li>

        <li>
            <a data-bs-toggle="collapse" href="#resellerMenu">
                🤝 reseller <span>▼</span>
            </a>
            <div class="collapse" id="resellerMenu">
                <a href="/ispbilling/reseller/add.php" class="submenu">Add Reseller</a>
                <a href="/ispbilling/reseller/list.php" class="submenu">Reseller List</a>
            </div>
        </li>

        <li>
            <a data-bs-toggle="collapse" href="#messageMenu">
                💬 Message <span>▼</span>
            </a>
            <div class="collapse" id="messageMenu">
                <a href="/ispbilling/message/send.php" class="submenu">SMS Send</a>
                <a href="/ispbilling/message/history.php" class="submenu">SMS History</a>
            </div>
        </li>

        <li>
            <a data-bs-toggle="collapse" href="#accountMenu">
                💰 account <span>▼</span>
            </a>
            <div class="collapse" id="accountMenu">
                <a href="/ispbilling/accounts/income/index.php">💰 Income</a>
		<a href="/ispbilling/accounts/expense/index.php">💸 Expense</a>
            </div>
        </li>

        <li>
            <a data-bs-toggle="collapse" href="#supportMenu">
                🎫 support <span>▼</span>
            </a>
            <div class="collapse" id="supportMenu">
                <a href="/ispbilling/support/ticket.php" class="submenu">Support Ticket</a>
            </div>
        </li>

        <li>
            <a href="/ispbilling/activity/index.php">
    📋 Activity Log
</a>
        </li>

        <li>
            <a href="/ispbilling/ISP Support/index.php">
                🛠 ISP Support
            </a>
        </li>

        <li>
            <a href="/ispbilling/Tutorial/index.php">
                📚 Tutorial
            </a>
        </li>

    </ul>

</div>

<style>

body{
    margin:0;
    background:#f5f7fb;
}
.sidebar{
    position:fixed;
    left:0;
    top:0;
    width:250px;
    height:100%;
    background:linear-gradient(180deg,#1e3a8a,#1e40af);
    overflow:auto;
}
.sidebar{
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    transition: all .3s ease;
}

.sidebar.hide-sidebar{
    left: -250px;
}

.main-content{
    margin-left: 250px;
    transition: all .3s ease;
}

.main-content.full-content{
    margin-left: 0;
}


.logo{
    padding:20px;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,.1);
}

.logo h3{
    color:#fff;
    margin:0;
    font-weight:700;
}

.sidebar ul{
    margin:0;
    padding:15px;
}

.sidebar ul li{
    list-style:none;
    margin-bottom:6px;
}

.sidebar ul li a{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:12px 15px;
    color:#fff;
    text-decoration:none;
    border-radius:10px;
    transition:.3s;
}

.sidebar ul li a:hover{
    background:rgba(255,255,255,.15);
}

.submenu{
    margin:5px 0 5px 15px;
    background:rgba(255,255,255,.08);
    font-size:13px;
}

</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>