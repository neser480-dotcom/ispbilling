<?php


if(isset($_GET['lang'])){
    $_SESSION['lang'] = $_GET['lang'];
}

$lang = $_SESSION['lang'] ?? 'en';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<title>ISP Billing</title>
</head>

<body>
<style>
.topbar{
    position:fixed;
    top:0;
    left:250px;
    right:0;
    height:70px;
    background:#fff;
    border-bottom:1px solid #e5e7eb;
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:0 25px;
    z-index:999;
    box-shadow:0 2px 10px rgba(0,0,0,.05);
}

.topbar-left{
    display:flex;
    align-items:center;
    gap:15px;
}

.menu-btn{
    border:none;
    background:none;
    font-size:22px;
    cursor:pointer;
}

.search-box{
    width:350px;
    height:40px;
    border:1px solid #d1d5db;
    border-radius:8px;
    padding:0 15px;
    outline:none;
}

.search-box:focus{
    border-color:#2563eb;
}

.topbar-right{
    display:flex;
    align-items:center;
    gap:20px;
}

.icon-box{
    position:relative;
    font-size:22px;
    cursor:pointer;
}

.badge-count{
    position:absolute;
    top:-6px;
    right:-10px;
    background:#ef4444;
    color:#fff;
    width:18px;
    height:18px;
    border-radius:50%;
    font-size:10px;
    display:flex;
    align-items:center;
    justify-content:center;
}

.profile{
    display:flex;
    align-items:center;
    gap:10px;
}

.profile{
    position:relative;
    cursor:pointer;
}

.profile-dropdown{
    position:absolute;
    top:60px;
    right:0;
    width:200px;
    background:#8ee7ff;
    border-radius:12px;
    box-shadow:0 5px 20px rgba(0,0,0,.15);
    display:none;
    z-index:9999;
}

.profile-dropdown a{
    display:block;
    padding:12px 15px;
    text-decoration:none;
    color:#fff;
}

.profile-dropdown a:hover{
    background:rgba(255,255,255,.15);
}

.profile-dropdown.show{
    display:block;
}

.avatar{
    width:40px;
    height:40px;
    border-radius:50%;
    background:#2563eb;
    color:#fff;
    font-weight:bold;
    display:flex;
    justify-content:center;
    align-items:center;
}

.profile-info{
    display:flex;
    flex-direction:column;
    line-height:18px;
}

.profile-info strong{
    font-size:14px;
}

.profile-info small{
    color:#6b7280;
}

.logout-btn{
    background:#ef4444;
    color:#fff;
    padding:8px 15px;
    border-radius:6px;
    text-decoration:none;
}

.logout-btn:hover{
    background:#dc2626;
    color:#fff;
}

.main-content{
    margin-left:250px;
    margin-top:70px;
    padding:20px;
    min-height:10vh;
}

body.dark-mode{
    background:#1f2937 !important;
    color:#fff;
}

body.dark-mode .card{
    background:#2d3748 !important;
    color:#fff !important;
}

body.dark-mode .topbar{
    background:#111827 !important;
}

body.dark-mode .sidebar{
    background:#0f172a !important;
}

body.dark-mode table{
    color:#fff;
}
.language-dropdown{
    position:relative;
    cursor:pointer;
}

.lang-menu{
    display:none;
    position:absolute;
    top:30px;
    right:0;
    background:#fff;
    min-width:120px;
    border-radius:8px;
    box-shadow:0 3px 15px rgba(0,0,0,.15);
    z-index:9999;
}

.lang-menu a{
    display:block;
    padding:10px;
    text-decoration:none;
    color:#333;
}

.lang-menu a:hover{
    background:#f5f5f5;
}

.lang-menu.show{
    display:block;
}
</style>

<div class="topbar">

    <div class="topbar-left">

        <button class="menu-btn">
            ☰
        </button>

        <input
            type="text"
            class="search-box"
            placeholder="Search customer, mobile, invoice..."
        >

    </div>

   <div class="topbar-right">

    <div class="icon-box" data-bs-toggle="modal" data-bs-target="#billingCycleModal">
    📅
</div>

    <div class="icon-box">
        💬
        <span class="badge-count">5</span>
    </div>

<div class="icon-box" id="themeToggle" title="Day / Night Mode">
    🌙
</div>
<div class="language-dropdown">

    <span id="langBtn">
        EN ▼
    </span>

    <div class="lang-menu" id="langMenu">
        <a href="?lang=en">English</a>
        <a href="?lang=bn">বাংলা</a>
    </div>

</div>
    <div class="profile" id="profileBtn">

        <div class="avatar">
            A
        </div>

        <div class="profile-info">
            <strong>Admin</strong>
            <small>Super Admin</small>
        </div>

        <div class="profile-dropdown" id="profileMenu">
    <a href="/ispbilling/settings/profile.php">
        👤 Profile
    </a>

    <a href="logout.php">
        🚪 Logout
    </a>
</div>

    </div>

</div>

    </div>

</div>