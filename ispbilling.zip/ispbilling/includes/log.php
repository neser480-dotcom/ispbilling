<?php

function addLog($conn,$user,$module,$action,$description){

    mysqli_query($conn,"
        INSERT INTO activity_logs
        (user_name,module_name,action_type,description)
        VALUES
        (
            '$user',
            '$module',
            '$action',
            '$description'
        )
    ");

}