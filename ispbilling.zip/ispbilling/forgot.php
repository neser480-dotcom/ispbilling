<?php
include "config/db.php";

$msg = "";

if(isset($_POST['reset'])){

    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $newpass  = mysqli_real_escape_string($conn,$_POST['password']);

    $check = mysqli_query($conn,"SELECT * FROM users WHERE username='$username'");

    if(mysqli_num_rows($check)>0){

        mysqli_query($conn,"UPDATE users SET password='$newpass' WHERE username='$username'");

        $msg = "Password Updated Successfully";

    }else{
        $msg = "User Not Found";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Forgot Password - NetFee</title>
<style>
body{
height:100vh;
display:flex;
justify-content:center;
align-items:center;
background:linear-gradient(135deg,#0f172a,#2563eb,#06b6d4);
font-family:Segoe UI;
}
.box{
width:420px;
background:#fff;
padding:35px;
border-radius:20px;
box-shadow:0 15px 40px rgba(0,0,0,.2);
}
h2{
text-align:center;
color:#2563eb;
margin-bottom:20px;
}
input{
width:100%;
padding:12px;
margin:10px 0;
border:1px solid #ddd;
border-radius:10px;
}
button{
width:100%;
padding:12px;
background:#2563eb;
color:#fff;
border:none;
border-radius:10px;
cursor:pointer;
}
.footer{
text-align:center;
margin-top:15px;
}
a{
text-decoration:none;
color:#2563eb;
}
</style>
</head>
<body>

<div class="box">

<h2>Forgot Password</h2>

<form method="post">

<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="New Password" required>


<button type="submit" name="reset">
Reset Password
</button>

</form>
<p style="text-align:center;color:green;">
    <?php echo $msg; ?>
</p>

<div class="footer">
<a href="login.php">Back To Login</a>
</div>

</div>

</body>
</html>