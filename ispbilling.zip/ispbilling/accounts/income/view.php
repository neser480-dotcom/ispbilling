<?php
include '../../config/db.php';

$id = $_GET['id'];

$data = mysqli_query($conn,"SELECT * FROM income WHERE id='$id'");
$row = mysqli_fetch_assoc($data);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Income</title>

    <link rel="stylesheet" href="../../assets/css/main.css">

    <style>
        .card-box{
            background:white;
            padding:25px;
            border-radius:12px;
            box-shadow:0 5px 15px rgba(0,0,0,0.05);
            width:400px;
            margin:auto;
            margin-top:50px;
        }

        .item{
            margin-bottom:12px;
            padding:10px;
            background:#f3f4f6;
            border-radius:8px;
        }

        .label{
            font-weight:bold;
        }

        .amount{
            font-size:20px;
            font-weight:bold;
            color:#10b981;
        }

        .btn-back{
            display:inline-block;
            margin-top:15px;
            padding:8px 12px;
            background:#111827;
            color:white;
            text-decoration:none;
            border-radius:6px;
        }

        h2{
            text-align:center;
        }
    </style>
</head>

<body>

<div class="card-box">

<h2>💰 Income Details</h2>

<div class="item">
    <div class="label">Title</div>
    <div><?= $row['title'] ?></div>
</div>

<div class="item">
    <div class="label">Amount</div>
    <div class="amount">৳ <?= $row['amount'] ?></div>
</div>

<div class="item">
    <div class="label">Note</div>
    <div><?= $row['note'] ?></div>
</div>

<div class="item">
    <div class="label">Date</div>
    <div><?= $row['created_at'] ?></div>
</div>

<a class="btn-back" href="index.php">← Back</a>

</div>

</body>
</html>