<?php
include '../../config/db.php';

if(isset($_POST['save'])){
    $title = $_POST['title'];
    $amount = $_POST['amount'];
    $note = $_POST['note'];

    mysqli_query($conn,"INSERT INTO income(title,amount,note)
    VALUES('$title','$amount','$note')");

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Income</title>

    <link rel="stylesheet" href="../../assets/css/main.css">

    <style>
        .card-box{
            background:white;
            padding:20px;
            border-radius:12px;
            box-shadow:0 5px 15px rgba(0,0,0,0.05);
            width:400px;
            margin:auto;
            margin-top:50px;
        }

        input, textarea{
            width:100%;
            padding:10px;
            margin-bottom:12px;
            border:1px solid #ddd;
            border-radius:6px;
        }

        .btn{
            width:100%;
            padding:10px;
            background:linear-gradient(45deg,#10b981,#06b6d4);
            color:white;
            border:none;
            border-radius:8px;
            cursor:pointer;
        }

        h2{
            text-align:center;
        }
    </style>
</head>

<body>

<div class="card-box">

<h2>💰 Add Income</h2>

<form method="POST">

    Title:
    <input type="text" name="title" required>

    Amount:
    <input type="number" name="amount" required>

    Note:
    <textarea name="note"></textarea>

    <button class="btn" name="save">Save Income</button>

</form>

</div>

</body>
</html>