<?php
include '../../config/db.php';

$data = mysqli_query($conn,"SELECT * FROM expense ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Expense List</title>

    <link rel="stylesheet" href="../../assets/css/main.css">

    <style>
        .card-box{
            background:white;
            padding:20px;
            border-radius:12px;
            box-shadow:0 5px 15px rgba(0,0,0,0.05);
        }

        .btn-add{
            background:linear-gradient(45deg,#4f46e5,#06b6d4);
            color:white;
            padding:8px 15px;
            border-radius:8px;
            text-decoration:none;
            display:inline-block;
            margin-bottom:10px;
        }

        table{
            width:100%;
            border-collapse:collapse;
        }

        table th{
            background:#111827;
            color:white;
            padding:10px;
        }

        table td{
            padding:10px;
            border-bottom:1px solid #ddd;
        }

        .total-box{
            margin-top:15px;
            padding:12px;
            background:#ef4444;
            color:white;
            border-radius:10px;
            font-weight:bold;
        }
    </style>
</head>

<body>

<div class="card-box">

<h2>💸 Expense List</h2>

<a class="btn-add" href="add.php">+ Add Expense</a>
<a href="/ispbilling/dashboard.php" style="
    display:inline-block;
    margin-bottom:15px;
    padding:8px 12px;
    background:#111827;
    color:white;
    text-decoration:none;
    border-radius:6px;
">
← Back to Dashboard
</a>
<table>
<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Amount</th>
    <th>Date</th>
</tr>

<?php 
$total = 0;
while($row = mysqli_fetch_assoc($data)){
$total += $row['amount'];
?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['title'] ?></td>
    <td>৳ <?= $row['amount'] ?></td>
    <td><?= $row['created_at'] ?></td>
</tr>
<?php } ?>

</table>

<div class="total-box">
Total Expense: ৳ <?= $total ?>
</div>

</div>

</body>
</html>