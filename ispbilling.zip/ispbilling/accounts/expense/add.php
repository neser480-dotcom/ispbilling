<?php
include '../../config/db.php';

if(isset($_POST['save'])){
    $title = $_POST['title'];
    $amount = $_POST['amount'];
    $note = $_POST['note'];

    mysqli_query($conn,"INSERT INTO expense(title,amount,note)
    VALUES('$title','$amount','$note')");

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Expense</title>

    <link rel="stylesheet" href="../../assets/css/main.css">

    <style>
        .card-box{
            background:white;
            padding:20px;
            border-radius:12px;
            box-shadow:0 5px 15px rgba(0,0,0,0.05);
            width:400px;
            margin:auto;
            margin-top:50px;
        }

        input, textarea{
            width:100%;
            padding:10px;
            margin-top:5px;
            margin-bottom:15px;
            border:1px solid #ddd;
            border-radius:6px;
        }

        .btn{
            background:linear-gradient(45deg,#ef4444,#f97316);
            color:white;
            padding:10px;
            border:none;
            width:100%;
            border-radius:8px;
            cursor:pointer;
        }

        .btn:hover{
            opacity:0.9;
        }

        h2{
            text-align:center;
        }
    </style>
</head>

<body>

<div class="card-box">

<h2>💸 Add Expense</h2>

<form method="POST">

    Title:
    <input type="text" name="title" required>

    Amount:
    <input type="number" name="amount" required>

    Note:
    <textarea name="note"></textarea>

    <button class="btn" name="save">Save Expense</button>

</form>

</div>

</body>
</html>