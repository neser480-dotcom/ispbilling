<?php
include '../config/db.php';

$data = mysqli_query($conn,"SELECT status, COUNT(*) as total FROM customers GROUP BY status");
?>

<h2>BTRC Report</h2>

<table border="1" cellpadding="10">

<tr>
<th>Status</th>
<th>Total Customers</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>
<td><?= $row['status'] ?></td>
<td><?= $row['total'] ?></td>
</tr>

<?php } ?>

</table>