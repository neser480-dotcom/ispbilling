<?php
include '../config/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="customers.csv"');

$output = fopen("php://output", "w");

fputcsv($output, ['ID','Customer ID','Name','Phone','Package','Bill','Status']);

$data = mysqli_query($conn,"SELECT * FROM customers");

while($row = mysqli_fetch_assoc($data)){
    fputcsv($output, [
        $row['id'],
        $row['customer_id'],
        $row['name'],
        $row['phone'],
        $row['package_name'],
        $row['monthly_bill'],
        $row['status']
    ]);
}

fclose($output);
exit;
?>