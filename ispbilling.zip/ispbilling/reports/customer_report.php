<?php

include '../includes/auth.php';
include '../config/db.php';

$data = mysqli_query($conn,"
SELECT
billing_month,
COUNT(*) total_bill,
SUM(amount) amount,
SUM(due_amount) due
FROM billings
GROUP BY billing_month
ORDER BY billing_month DESC
");

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-primary text-white">
Monthly Report
</div>

<div class="card-body">

<table class="table table-bordered">

<tr>
<th>Month</th>
<th>Total Bills</th>
<th>Total Amount</th>
<th>Total Due</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['billing_month'] ?></td>
<td><?= $row['total_bill'] ?></td>
<td><?= $row['amount'] ?></td>
<td><?= $row['due'] ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

<?php include '../includes/footer.php'; ?>