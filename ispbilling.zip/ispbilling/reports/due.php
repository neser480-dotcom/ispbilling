<?php
include '../config/db.php';

$data = mysqli_query($conn,"
SELECT
billings.*,
customers.customer_id,
customers.name,
customers.phone
FROM billings
LEFT JOIN customers
ON customers.id = billings.customer_id
WHERE billings.due_amount > 0
ORDER BY billings.due_amount DESC
");

$total_due = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT SUM(due_amount) as total_due
FROM billings
WHERE due_amount > 0
")
);

include '../includes/topbar.php';
include '../includes/sidebar.php';
?>
<div class="main-content">
<div class="card">

<div class="card-header bg-danger text-white">
Due Report
</div>

<div class="card-body">

<div class="alert alert-danger">

<h4>
Total Due :
<?= number_format($total_due['total_due'] ?? 0,2) ?> ৳
</h4>

</div>

<table class="table table-bordered table-striped">

<thead>

<tr>

<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Phone</th>
<th>Month</th>
<th>Amount</th>
<th>Due</th>
<th>Status</th>

</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= $row['customer_id'] ?></td>

<td><?= $row['name'] ?></td>

<td><?= $row['phone'] ?></td>

<td><?= $row['billing_month'] ?></td>

<td><?= $row['amount'] ?></td>

<td>
<b class="text-danger">
<?= $row['due_amount'] ?>
</b>
</td>

<td>

<?php

if($row['status']=="Paid")
{
    echo "<span class='badge bg-success'>Paid</span>";
}
elseif($row['status']=="Partial")
{
    echo "<span class='badge bg-warning'>Partial</span>";
}
else
{
    echo "<span class='badge bg-danger'>Unpaid</span>";
}

?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

<?php include '../includes/footer.php'; ?>