<?php

include '../includes/auth.php';
include '../config/db.php';

$data = mysqli_query($conn,"
SELECT *
FROM customers
ORDER BY id DESC
");

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="card">

<div class="card-header bg-success text-white">
Customer Report
</div>

<div class="card-body">

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Phone</th>
<th>Package</th>
<th>Bill</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>
<td><?= $row['customer_id'] ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['phone'] ?></td>
<td><?= $row['package_name'] ?></td>
<td><?= $row['monthly_bill'] ?></td>
<td><?= $row['status'] ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

<?php include '../includes/footer.php'; ?>