<?php
include '../config/db.php';

$total = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT SUM(amount) total
FROM payments
"));

$today = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT SUM(amount) total
FROM payments
WHERE payment_date=CURDATE()
"));

$month = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT SUM(amount) total
FROM payments
WHERE MONTH(payment_date)=MONTH(CURDATE())
AND YEAR(payment_date)=YEAR(CURDATE())
"));

$data = mysqli_query($conn,"
SELECT payments.*, customers.name
FROM payments
LEFT JOIN customers
ON customers.id=payments.customer_id
ORDER BY payments.id DESC
");

include '../includes/topbar.php';
include '../includes/sidebar.php';
?>
<div class="main-content">
<div class="row">

<div class="col-md-4">
<div class="card">
<div class="card-body">
<h5>Total Collection</h5>
<h2><?= $total['total'] ?? 0 ?></h2>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card">
<div class="card-body">
<h5>Today's Collection</h5>
<h2><?= $today['total'] ?? 0 ?></h2>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card">
<div class="card-body">
<h5>Monthly Collection</h5>
<h2><?= $month['total'] ?? 0 ?></h2>
</div>
</div>
</div>

</div>

<table class="table table-bordered mt-3">

<tr>
<th>Name</th>
<th>Amount</th>
<th>Method</th>
<th>Date</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>
<td><?= $row['name'] ?></td>
<td><?= $row['amount'] ?></td>
<td><?= $row['payment_method'] ?></td>
<td><?= $row['payment_date'] ?></td>
</tr>

<?php } ?>

</table>

<?php include '../includes/footer.php'; ?>