<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/db.php';
include '../includes/topbar.php';
include '../includes/sidebar.php';

$data = mysqli_query($conn,"
SELECT *
FROM customers
WHERE pppoe_username='' 
OR pppoe_username IS NULL
ORDER BY id DESC
");

$total = mysqli_num_rows($data);
?>

<div class="main-content">

<div class="card shadow-sm">

<div class="card-header bg-secondary text-white">
    Other Customers
</div>

<div class="card-body">

<div class="alert alert-info">
Total Data : <b><?= $total ?></b>
</div>

<table class="table table-bordered table-hover">

<thead>
<tr>
<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Mobile</th>
<th>Status</th>
</tr>
</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['customer_id'] ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['phone'] ?></td>
<td><?= $row['status'] ?></td>
</tr>

<?php } ?>

</tbody>

</table>

</div>
</div>

</div>

<?php include '../includes/footer.php'; ?>