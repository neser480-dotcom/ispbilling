<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

/* শুধু এই ২টা লাইন পরিবর্তন করবে */

$title = "Free Customer";

$where = "WHERE status='Free'";

/* -------------------------- */

$data = mysqli_query($conn,"
SELECT *
FROM customers
$where
ORDER BY id DESC
");

$total = mysqli_num_rows($data);
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white d-flex justify-content-between align-items-center"
style="background:linear-gradient(90deg,#008cff,#00c6ff);">

<h5 class="mb-0">
<?= $title ?>
</h5>

<div class="d-flex gap-2">

<a href="" class="btn btn-light btn-sm">
<i class="fa fa-rotate-right"></i>
</a>

<a href="javascript:history.back()"
class="btn btn-light btn-sm">
<i class="fa fa-arrow-left"></i>
</a>

</div>

</div>

<div class="card-body">

<div class="alert alert-primary">
Total Data : <b><?= $total ?></b>
</div>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Mobile</th>
<th>PPPoE</th>
<th>Package</th>
<th>Bill</th>
<th>Status</th>
<th width="120">Action</th>

</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= $row['customer_id'] ?></td>

<td><?= $row['name'] ?></td>

<td><?= $row['mobile'] ?></td>

<td><?= $row['pppoe_username'] ?></td>

<td><?= $row['package_name'] ?></td>

<td>৳<?= $row['monthly_bill'] ?></td>

<td>

<span class="badge bg-success">
<?= $row['status'] ?>
</span>

</td>

<td>

<div class="dropdown">

<button class="btn btn-primary btn-sm dropdown-toggle"
data-bs-toggle="dropdown">
Action
</button>

<ul class="dropdown-menu">

<li>
<a class="dropdown-item"
href="view.php?id=<?= $row['id'] ?>">
Profile
</a>
</li>

<li>
<a class="dropdown-item"
href="edit.php?id=<?= $row['id'] ?>">
Edit
</a>
</li>

<li>
<a class="dropdown-item text-danger"
href="delete.php?id=<?= $row['id'] ?>">
Delete
</a>
</li>

</ul>

</div>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>