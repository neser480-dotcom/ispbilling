<?php
include '../config/db.php';
$id = $_GET['id'];
$customer = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customers WHERE id='$id'"));
?>
<form method="POST" action="process_recharge.php">
    <div class="row">
        <div class="col-6">Name: <b><?= $customer['name'] ?></b></div>
        <div class="col-6">PPPoE: <b><?= $customer['customer_id'] ?></b></div>
        <div class="col-6">Monthly Bill: <b>৳<?= $customer['monthly_bill'] ?></b></div>
        <div class="col-6">Balance: <b>৳<?= $customer['balance'] ?></b></div>
    </div>
    <hr>
    <label>Amount</label>
    <input type="number" name="amount" class="form-control" required>
    <button type="submit" class="btn btn-primary mt-3 w-100">Pay Now</button>
</form>