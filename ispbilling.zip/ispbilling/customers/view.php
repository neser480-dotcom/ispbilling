<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$id = (int)$_GET['id'];

$data = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT * FROM customers
        WHERE id='$id'
    ")
);
?>

<div class="main-content">

    <div class="card shadow border-0">

        <div class="card-header bg-primary text-white">
            👤 Customer Details
        </div>

        <div class="card-body">

            <table class="table table-bordered">

                <tr>
                    <th width="250">Customer ID</th>
                    <td><?= $data['customer_id'] ?? '' ?></td>
                </tr>

                <tr>
                    <th>Customer Name</th>
                    <td><?= $data['name'] ?? '' ?></td>
                </tr>

                <tr>
                    <th>Phone</th>
                    <td><?= $data['phone'] ?? '' ?></td>
                </tr>

                <tr>
                    <th>Address</th>
                    <td><?= $data['address'] ?? '' ?></td>
                </tr>

                <tr>
                    <th>Package</th>
                    <td><?= $data['package_name'] ?? '' ?></td>
                </tr>

                <tr>
                    <th>Monthly Bill</th>
                    <td><?= $data['monthly_bill'] ?? '' ?> ৳</td>
                </tr>

                <tr>
                    <th>Status</th>
                    <td>
                        <?php if(($data['status'] ?? '')=='Active'){ ?>
                            <span class="badge bg-success">Active</span>
                        <?php }elseif(($data['status'] ?? '')=='Inactive'){ ?>
                            <span class="badge bg-warning">Inactive</span>
                        <?php }else{ ?>
                            <span class="badge bg-danger"><?= $data['status'] ?? 'Unknown' ?></span>
                        <?php } ?>
                    </td>
                </tr>

                <tr>
                    <th>Created Date</th>
                    <td><?= $data['created_at'] ?? '' ?></td>
                </tr>

            </table>

            <a href="edit.php?id=<?= $data['id'] ?>"
               class="btn btn-warning">
               ✏ Edit Customer
            </a>

            <a href="list.php"
               class="btn btn-secondary">
               ← Back
            </a>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>