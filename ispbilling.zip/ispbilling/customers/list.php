<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$where = "WHERE 1=1";

if(isset($_GET['search']) && $_GET['search']!=''){
    $s = mysqli_real_escape_string($conn,$_GET['search']);
    $where .= " AND name LIKE '%$s%'";
}

if(isset($_GET['status']) && $_GET['status']!=''){
    $st = mysqli_real_escape_string($conn,$_GET['status']);
    $where .= " AND status='$st'";
}

$total_customer = mysqli_num_rows(
    mysqli_query($conn,"SELECT * FROM customers")
);

$total_bill = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT SUM(monthly_bill) AS total
    FROM customers
    ")
);

$total_balance = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT SUM(balance) AS total
    FROM customers
    ")
);

$data = mysqli_query($conn,"
SELECT *
FROM customers
$where
ORDER BY id DESC
");

if(!$data){
    die(mysqli_error($conn));
}
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white d-flex justify-content-between align-items-center"
style="background:#2d89ef;">

<h4 class="mb-0">Customers</h4>

<div>

<a href="add.php" class="btn btn-light btn-sm">
➕
</a>

<a href="list.php" class="btn btn-light btn-sm">
🔄
</a>

</div>

</div>

<div class="card-body">

<div class="card shadow-sm border-0 mb-3">

<div class="card-body text-white"
style="background:#2d89ef;">

<div class="row">

<div class="col-md-7">

⚙ Total Data :
<span class="badge bg-light text-primary">
<?= $total_customer ?>
</span>

&nbsp;&nbsp;

Monthly Fee :
<b>
৳<?= number_format($total_bill['total'] ?? 0) ?>
</b>

&nbsp;&nbsp;

Balance :
<b>
৳<?= number_format($total_balance['total'] ?? 0) ?>
</b>

</div>

<div class="col-md-5">

<form method="GET">

<input
type="text"
name="search"
class="form-control"
placeholder="Search Customer">

</form>

</div>

</div>

</div>

</div>

<table class="table table-hover align-middle bg-white">
    <thead class="table-light">
        <tr>
            <th><input type="checkbox" class="form-check-input"></th>
            <th>ID ↓↑</th>
            <th>Name/PPPoE ↑↓</th>
            <th>Mobile/Address ↑↓</th>
            <th>Package ↑↓</th>
            <th>Bill/Balance ↑↓</th>
            <th>Bill/Promise Date ↑↓</th>
            <th>Day Left ↑↓</th>
            <th>Status ↑↓</th>
            <th>Action</th>
        </tr>
    </thead>
<div class="modal fade" id="rechargeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Recharge</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="modalBodyContent">
        </div>
    </div>
  </div>
</div>
    <tbody>
        <?php while($row=mysqli_fetch_assoc($data)){ ?>
        <tr>
            <td><input type="checkbox" class="form-check-input"></td>
            
            <td><?= $row['id'] ?></td>
            
            <td>
                <div class="fw-bold text-dark"><?= $row['name'] ?></div>
                <div class="text-muted" style="font-size: 13px;"><?= $row['customer_id'] ?></div>
            </td>
            
            <td>
                <div class="text-dark">📱 <?= $row['phone'] ?></div>
                <div class="text-muted" style="font-size: 13px;">📍 <?= $row['address'] ?? 'N/A' ?></div>
            </td>
            
            <td><?= $row['package_name'] ?></td>
            
            <td>
                <div class="text-dark">৳<?= $row['monthly_bill'] ?></div>
                <div class="text-success fw-bold" style="font-size: 13px;">৳<?= $row['balance'] ?></div>
            </td>
            
            <td>
                <div class="text-muted" style="font-size: 13px;"><?= $row['bill_date'] ?? '2026/07/02 12:19 PM' ?></div>
                <div class="text-danger" style="font-size: 13px;"><?= $row['promise_date'] ?? 'N/A' ?></div>
            </td>
            
            <td>
                <?php 
                    // ডাটাবেস থেকে day_left কলাম আসবে, না থাকলে ডেমো 24 ব্যবহার করা হয়েছে
                    $day_left = $row['day_left'] ?? 24; 
                    if($day_left < 0) {
                        echo '<span class="badge bg-danger p-2 rounded-1">'.$day_left.'</span>';
                    } else {
                        echo '<span class="badge text-success border border-success bg-white p-2 rounded-1">'.$day_left.'</span>';
                    }
                ?>
            </td>
            
            <td>
                <div class="d-flex flex-column gap-1 align-items-start">
                    <?php 
                        // পেমেন্ট স্ট্যাটাস (ডাটাবেস অনুযায়ী পরিবর্তন করে নেবেন)
                        $payment_status = $row['payment_status'] ?? 'paid'; 
                        if($payment_status == 'paid'){
                            echo '<span class="badge bg-success rounded-1">paid</span>';
                        } else {
                            echo '<span class="badge bg-warning text-dark rounded-1">unpaid</span>';
                        }
                    ?>
                    
                    <?php if(strtolower($row['status']) == "active"){ ?>
                        <span class="badge bg-primary rounded-1">active</span>
                    <?php }else{ ?>
                        <span class="badge bg-secondary rounded-1"><?= $row['status'] ?></span>
                    <?php } ?>
                </div>
            </td>
            
            <td class="text-center">
    <div class="dropdown">
        <button class="btn btn-link text-decoration-none fw-bold" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 20px; padding: 0;">
            •••
        </button>
        <ul class="dropdown-menu shadow border-0" style="background-color: #2d89ef;">
            <li><a class="dropdown-item text-white" href="view.php?id=<?= $row['id'] ?>">👤 Profile</a></li>
            <li>
    <a class="dropdown-item text-white recharge-btn" href="javascript:void(0)" data-id="<?= $row['id'] ?>">
        💵 Recharge
    </a>
</li>
            <li><a class="dropdown-item text-white" href="edit.php?id=<?= $row['id'] ?>">✏️ Edit</a></li>
            <li><a class="dropdown-item text-white" href="#">📊 Report</a></li>
            <li><a class="dropdown-item text-white" href="#">📝 Note</a></li>
            <li><hr class="dropdown-divider bg-light"></li>
            <li><a class="dropdown-item text-white" href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete Customer?')">🗑️ Delete</a></li>
        </ul>
    </div>
</td>
        </tr>
        <?php } ?>
    </tbody>
</div>

</div>

</div>
<div class="modal fade" id="rechargeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Recharge</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="modalBodyContent">
         </div>
    </div>
  </div>
</div>
<script>
// এই স্ক্রিপ্টটি রিচার্জ বাটনে ক্লিক করলে ডাটা মডালে পাঠাবে
document.querySelectorAll('.recharge-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        let id = this.getAttribute('data-id');
        // রিচার্জ পেজ থেকে ডাটা এনে মডালে দেখাবে
        fetch('recharge_modal.php?id=' + id)
            .then(response => response.text())
            .then(data => {
                document.getElementById('modalBodyContent').innerHTML = data;
                new bootstrap.Modal(document.getElementById('rechargeModal')).show();
            });
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</table>

<?php include '../includes/footer.php'; ?>