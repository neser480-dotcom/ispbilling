<?php
include '../config/db.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $id = $_POST['id'];
    $amount = $_POST['amount'];

    // বর্তমান ব্যালেন্স আপডেট করা
    $sql = "UPDATE customers SET balance = balance + '$amount' WHERE id = '$id'";
    
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Recharge Successful!'); window.location='list.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>