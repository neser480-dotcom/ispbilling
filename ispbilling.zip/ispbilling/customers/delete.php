<?php

include '../includes/auth.php';
include '../config/db.php';

$id = $_GET['id'];

mysqli_query(
$conn,
"DELETE FROM customers WHERE id='$id'"
);

header("Location:list.php");
exit();