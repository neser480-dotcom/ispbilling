<?php
include '../config/db.php';

$customer_id = $_POST['customer_id'];
$mikrotik_id = $_POST['mikrotik_id'];
$package_id  = $_POST['package_id'];
$monthly_bill = $_POST['monthly_fee'];
$balance     = $_POST['balance'];

$pppoe_username = $_POST['pppoe_username'];
$pppoe_password = $_POST['pppoe_password'];

$area_id     = $_POST['area_id'];
$sub_area_id = $_POST['sub_area_id'];

$name     = $_POST['name'];
$mobile   = $_POST['mobile'];
$nid_no   = $_POST['nid_no'];
$birth_date = $_POST['birth_date'];
$email    = $_POST['email'];
$address  = $_POST['address'];

$billing_cycle   = $_POST['billing_cycle'];
$connection_date = $_POST['connection_date'];
$connection_fee  = $_POST['connection_fee'];

$billing_type = $_POST['billing_type'];
$status       = $_POST['status'];

$reference_name   = $_POST['reference_name'];
$reference_mobile = $_POST['reference_mobile'];

$auto_connection = isset($_POST['auto_connection']) ? 1 : 0;
$continue_next_month = isset($_POST['continue_next_month']) ? 1 : 0;

$comments = $_POST['comments'];

$result = mysqli_query($conn,"
INSERT INTO customers (

customer_id,
mikrotik_id,
package_id,
monthly_bill,
balance,

pppoe_username,
pppoe_password,

area_id,
sub_area_id,

name,
phone,
nid_no,
birth_date,
email,
address,

billing_cycle,
connection_date,
connection_fee,

billing_type,
status,

reference_name,
reference_mobile,

auto_connection,
continue_next_month,

comments

) VALUES (

'$customer_id',
'$mikrotik_id',
'$package_id',
'$monthly_bill',
'$balance',

'$pppoe_username',
'$pppoe_password',

'$area_id',
'$sub_area_id',

'$name',
'$mobile',
'$nid_no',
'$birth_date',
'$email',
'$address',

'$billing_cycle',
'$connection_date',
'$connection_fee',

'$billing_type',
'$status',

'$reference_name',
'$reference_mobile',

'$auto_connection',
'$continue_next_month',

'$comments'

)
");

if(!$result){
    die(mysqli_error($conn));
}

header("Location: list.php");
exit;