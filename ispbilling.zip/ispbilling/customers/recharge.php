<?php
include '../config/db.php';
$id = $_GET['id'];
$customer = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customers WHERE id='$id'"));
?>

<div class="card shadow">
    <div class="card-header text-white" style="background:#2d89ef;">
        <h5>Recharge Customer: <?= $customer['name'] ?></h5>
    </div>
    <div class="card-body">
        <form action="process_recharge.php" method="POST">
            <input type="hidden" name="id" value="<?= $customer['id'] ?>">
            
            <div class="mb-3">
                <label>Customer Name</label>
                <input type="text" class="form-control" value="<?= $customer['name'] ?>" readonly>
            </div>
            
            <div class="mb-3">
                <label>Package Price</label>
                <input type="text" class="form-control" value="<?= $customer['monthly_bill'] ?>" readonly>
            </div>

            <div class="mb-3">
                <label>Amount to Recharge (৳)</label>
                <input type="number" name="amount" class="form-control" required placeholder="Enter amount">
            </div>

            <button type="submit" class="btn btn-primary">Confirm Recharge</button>
        </form>
    </div>
</div>