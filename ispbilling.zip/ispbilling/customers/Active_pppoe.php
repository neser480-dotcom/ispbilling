<?php
include '../config/db.php';
include '../includes/topbar.php';
include '../includes/sidebar.php';
$data = mysqli_query($conn,"
SELECT *
FROM customers
WHERE status='Active'
AND pppoe_username IS NOT NULL
AND pppoe_username!=''
ORDER BY id DESC
");

$total = mysqli_num_rows($data);
?>

<div class="main-content">

<div class="card shadow-sm">

<div class="card-header text-white d-flex justify-content-between align-items-center"
style="background:linear-gradient(90deg,#008cff,#00c6ff);">

<h5 class="mb-0">Active PPPoE Customer</h5>

<div class="d-flex gap-2">

<button class="btn btn-light btn-sm"
data-bs-toggle="collapse"
data-bs-target="#filterBox">
<i class="fa fa-filter"></i>
</button>

<a href="" class="btn btn-light btn-sm">
<i class="fa fa-rotate-right"></i>
</a>

<div class="dropdown">

<button class="btn btn-light btn-sm dropdown-toggle"
data-bs-toggle="dropdown">
</button>

<ul class="dropdown-menu dropdown-menu-end">

<li>
<a class="dropdown-item"
href="#"
onclick="window.print()">
<i class="fa fa-print"></i> Print
</a>
</li>

<li>
<a class="dropdown-item"
href="javascript:history.back()">
<i class="fa fa-arrow-left"></i> Back
</a>
</li>

</ul>

</div>

</div>

</div>

<div class="collapse" id="filterBox">

<div class="card-body border-bottom">

<form method="GET">

<div class="row">

<div class="col-md-4">
<input type="text"
name="search"
class="form-control"
placeholder="Search PPPoE">
</div>

<div class="col-md-2">
<button class="btn btn-primary">
Search
</button>
</div>

</div>

</form>

</div>

</div>

<div class="card-body">

<div class="alert alert-primary">
Total Data : <b><?= $total ?></b>
</div>

<table class="table table-bordered table-hover">

<thead>
<tr>
<th>ID</th>
<th>Name / PPPoE</th>
<th>Mobile</th>
<th>Package</th>
<th>Bill</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td>
<b><?= $row['name'] ?></b><br>
<?= $row['pppoe_username'] ?>
</td>

<td><?= $row['phone'] ?></td>

<td><?= $row['package_name'] ?></td>

<td>৳<?= $row['monthly_bill'] ?></td>

<td>
<span class="badge bg-success">Active</span>
</td>

<td>

<div class="dropdown">

<button class="btn btn-primary btn-sm dropdown-toggle"
data-bs-toggle="dropdown">
Action
</button>

<ul class="dropdown-menu">

<li>
<a class="dropdown-item"
href="view.php?id=<?= $row['id'] ?>">
Profile
</a>
</li>

<li>
<a class="dropdown-item"
href="edit.php?id=<?= $row['id'] ?>">
Edit
</a>
</li>

<li>
<a class="dropdown-item"
href="../billing/recharge.php?id=<?= $row['id'] ?>">
Recharge
</a>
</li>

<li>
<a class="dropdown-item text-danger"
href="delete.php?id=<?= $row['id'] ?>">
Delete
</a>
</li>

</ul>

</div>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php include '../includes/footer.php';?>