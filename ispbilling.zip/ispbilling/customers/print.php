<?php
include '../config/db.php';

$data = mysqli_query($conn,"SELECT * FROM customers");
?>

<script>
window.print();
</script>

<h2>Customer Print List</h2>

<table border="1" width="100%" cellpadding="5">

<tr>
<th>ID</th>
<th>Name</th>
<th>Phone</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>
<td><?= $row['id'] ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['phone'] ?></td>
<td><?= $row['status'] ?></td>
</tr>

<?php } ?>

</table>