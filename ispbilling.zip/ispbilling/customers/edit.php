<?php
include '../config/db.php';

$id = $_GET['id'];

$data = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM customers WHERE id='$id'")
);

if(isset($_POST['update']))
{
    $customer_id = $_POST['customer_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $package = $_POST['package'];
    $monthly_bill = $_POST['monthly_bill'];
    $status = $_POST['status'];

    mysqli_query($conn,"
    UPDATE customers SET

    customer_id='$customer_id',
    name='$name',
    phone='$phone',
    address='$address',
    package_name='$package',
    monthly_bill='$monthly_bill',
    status='$status'

    WHERE id='$id'
    ");

    header("Location:list.php");
    exit();
}

include '../includes/topbar.php';
include '../includes/sidebar.php';
?>

<div class="main-content">
<div class="card">

<div class="card-header bg-warning">
Edit Customer
</div>

<div class="card-body">

<form method="POST">

<input type="text" name="customer_id"
class="form-control mb-2"
value="<?= $data['customer_id'] ?>">

<input type="text" name="name"
class="form-control mb-2"
value="<?= $data['name'] ?>">

<input type="text" name="phone"
class="form-control mb-2"
value="<?= $data['phone'] ?>">

<input type="text" name="package"
class="form-control mb-2"
value="<?= $data['package_name'] ?>">

<input type="number" name="monthly_bill"
class="form-control mb-2"
value="<?= $data['monthly_bill'] ?>">

<textarea name="address"
class="form-control mb-2"><?= $data['address'] ?></textarea>

<select name="status"
class="form-control mb-3">

<option value="Active">Active</option>
<option value="Inactive">Inactive</option>

</select>

<button type="submit"
name="update"
class="btn btn-success">
Update Customer
</button>

</form>

</div>

</div>

<?php include '../includes/footer.php'; ?>