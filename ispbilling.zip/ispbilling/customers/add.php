<?php
include '../config/db.php';
include '../includes/topbar.php';
include '../includes/sidebar.php';
$where = "WHERE 1=1";

if(isset($_GET['search']) && $_GET['search'] != ''){
    $s = $_GET['search'];
    $where .= " AND name LIKE '%$s%'";
}

if(isset($_GET['status']) && $_GET['status'] != ''){
    $st = $_GET['status'];
    $where .= " AND status='$st'";
}

$data = mysqli_query($conn,"SELECT * FROM customers $where ORDER BY id DESC");
$mikrotiks = mysqli_query($conn,"SELECT * FROM mikrotik_servers");
$packages  = mysqli_query($conn,"SELECT * FROM packages");
$areas     = mysqli_query($conn,"SELECT * FROM areas");
?>
<div class="main-content">
<div class="card shadow-sm">
<div class="collapse mb-3" id="filterBox">

<div class="card">
<div class="card-body">

<form method="GET">

<div class="row">

<div class="col-md-4">
<input type="text" name="search" class="form-control" placeholder="Search Customer">
</div>

<div class="col-md-3">
<select name="status" class="form-control">
<option value="">All Status</option>
<option value="Active">Active</option>
<option value="Inactive">Inactive</option>
<option value="Expired">Expired</option>
</select>
</div>

<div class="col-md-3">
<button class="btn btn-primary">Filter</button>
</div>

</div>

</form>

</div>
</div>

</div>
<!-- HEADER -->
<div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

<div>
<b>Add New Customer</b>
</div>

<div>
<a href="list.php" class="btn btn-light btn-sm">Customer List</a>
</div>

</div>

<div class="card-body">

<form method="POST" action="insert.php">

<div class="row">

<!-- LEFT -->
<div class="col-md-6">

<input type="text" name="customer_id" class="form-control mb-2" placeholder="Customer ID">

<select name="mikrotik_id" class="form-control mb-2">
<option>Select MikroTik</option>
<?php while($m=mysqli_fetch_assoc($mikrotiks)){ ?>
<option value="<?= $m['id'] ?>"><?= $m['name'] ?></option>
<?php } ?>
</select>

<select name="package_id" class="form-control mb-2">
<option>Select Package</option>
<?php while($p=mysqli_fetch_assoc($packages)){ ?>
<option value="<?= $p['id'] ?>"><?= $p['name'] ?></option>
<?php } ?>
</select>

<input type="number" name="monthly_fee" class="form-control mb-2" placeholder="Monthly Fee">

<input type="number" name="balance" class="form-control mb-2" placeholder="Balance">

<input type="text" name="pppoe_username" class="form-control mb-2" placeholder="PPPoE Name">

<input type="text" name="pppoe_password" class="form-control mb-2" placeholder="Password">

<select name="area_id" class="form-control mb-2">
<option>Select Area</option>
<?php while($a=mysqli_fetch_assoc($areas)){ ?>
<option value="<?= $a['id'] ?>"><?= $a['area_name'] ?></option>
<?php } ?>
</select>

<select name="sub_area_id" class="form-control mb-2">
<option>Select Sub Area</option>
</select>

</div>

<!-- RIGHT -->
<div class="col-md-6">

<input type="text" name="name" class="form-control mb-2" placeholder="Name">

<input type="text" name="mobile" class="form-control mb-2" placeholder="Mobile">

<input type="text" name="nid_no" class="form-control mb-2" placeholder="NID No">

<input type="date" name="birth_date" class="form-control mb-2">

<input type="email" name="email" class="form-control mb-2" placeholder="E-mail">

<textarea name="address" class="form-control mb-2" placeholder="Address"></textarea>

<input type="text" name="billing_cycle" class="form-control mb-2" placeholder="Billing Cycle">

<input type="date" name="connection_date" class="form-control mb-2">

<input type="number" name="connection_fee" class="form-control mb-2" placeholder="Connection Fee">

<select name="billing_type" class="form-control mb-2">
<option value="PREPAID">Pre-Paid</option>
<option value="POSTPAID">Post-Paid</option>
</select>

<!-- STATUS -->
<div class="mb-2">
<label>Status:</label><br>

<label class="me-2">
<input type="radio" name="status" value="Active" checked> Active
</label>

<label class="me-2">
<input type="radio" name="status" value="Inactive"> Inactive
</label>

<label>
<input type="radio" name="status" value="Expired"> Expired
</label>
</div>

<input type="text" name="reference_name" class="form-control mb-2" placeholder="Reference Name">

<input type="text" name="reference_mobile" class="form-control mb-2" placeholder="Reference Mobile">

<!-- CHECKBOX -->
<div class="mb-2">

<label>
<input type="checkbox" name="auto_connection" value="1">
Automatic Connection ON/OFF
</label>

<br>

<label>
<input type="checkbox" name="continue_next_month" value="1">
Continue Next Month
</label>

</div>

<textarea name="comments" class="form-control mb-2" placeholder="Comment"></textarea>

</div>

</div>

<!-- FOOTER BUTTON -->
<div class="text-end mt-3">

<button class="btn btn-success">
Save Customer
</button>

</div>

</form>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>