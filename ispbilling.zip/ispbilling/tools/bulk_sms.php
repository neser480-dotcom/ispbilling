<?php

if(isset($_POST['msg'])){
    $msg = $_POST['msg'];
    echo "SMS Sent (Demo): " . $msg;
}
?>

<form method="POST">

<textarea name="msg" placeholder="Type SMS"></textarea><br>

<button>Send SMS</button>

</form>