<?php
include '../config/db.php';

if(isset($_POST['submit'])){

    $file = $_FILES['file']['tmp_name'];

    $handle = fopen($file,"r");

    while(($data = fgetcsv($handle,1000,",")) !== FALSE){

        mysqli_query($conn,"
        INSERT INTO customers(name,phone,status)
        VALUES(
            '$data[0]',
            '$data[1]',
            '$data[2]'
        )
        ");

    }

    fclose($handle);

    echo "Import Done!";
}
?>

<form method="POST" enctype="multipart/form-data">

<input type="file" name="file"><br><br>

<button name="submit">Import CSV</button>

</form>