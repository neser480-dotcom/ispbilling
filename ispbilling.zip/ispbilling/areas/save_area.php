<?php

if(isset($_POST['save'])){

    $name = mysqli_real_escape_string(
        $conn,
        $_POST['area_name']
    );

    $remarks = mysqli_real_escape_string(
        $conn,
        $_POST['remarks']
    );

    $result = mysqli_query($conn,"
        INSERT INTO areas(
            name,
            remarks
        )
        VALUES(
            '$name',
            '$remarks'
        )
    ");

    if($result){
        echo "<script>
        window.location='list.php';
        </script>";
        exit;
    }else{
        die(mysqli_error($conn));
    }
}
?>