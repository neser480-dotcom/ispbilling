<?php
include '../config/db.php';

$id = (int)$_GET['id'];

if(isset($_POST['update'])){

    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $remarks = mysqli_real_escape_string($conn,$_POST['remarks']);

    mysqli_query($conn,"
    UPDATE areas SET
    name='$name',
    remarks='$remarks'
    WHERE id='$id'
    ");

    header("Location: list.php");
    exit;
}

include '../includes/sidebar.php';
include '../includes/topbar.php';

$id = (int)$_GET['id'];

$area = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT * FROM areas
        WHERE id='$id'
    ")
);

if(isset($_POST['update'])){

    $name = mysqli_real_escape_string(
        $conn,
        $_POST['name']
    );

    $remarks = mysqli_real_escape_string(
        $conn,
        $_POST['remarks']
    );

    mysqli_query($conn,"
        UPDATE areas SET
        name='$name',
        remarks='$remarks'
        WHERE id='$id'
    ");

    header("Location:list.php");
    exit;
}
?>

<div class="main-content">

    <div class="card shadow">

        <div class="card-header bg-warning text-dark">
            Edit Area
        </div>

        <div class="card-body">

            <form method="POST">

                <label>Area Name</label>

                <input
                    type="text"
                    name="name"
                    value="<?= $area['name'] ?>"
                    class="form-control mb-3"
                    required>

                <label>Remarks</label>

                <textarea
                    name="remarks"
                    class="form-control mb-3"
                    rows="4"><?= $area['remarks'] ?></textarea>

                <button
                    type="submit"
                    name="update"
                    class="btn btn-success">
                    Update Area
                </button>

                <a href="list.php"
                   class="btn btn-secondary">
                    Back
                </a>

            </form>

        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>