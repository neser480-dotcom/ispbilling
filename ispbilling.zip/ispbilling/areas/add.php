<?php
include '../config/db.php';

if(isset($_POST['save'])){
    mysqli_query($conn,"
    INSERT INTO areas(name, description)
    VALUES(
        '{$_POST['name']}',
        '{$_POST['description']}'
    )
    ");

    header("Location:list.php");
    exit;
}

include '../includes/topbar.php';
include '../includes/sidebar.php';
?>
<div class="main-content">

<div class="card shadow-sm">
<div class="card-header bg-primary text-white">
Add New Area
</div>

<div class="card-body">

<form method="POST">

<label>Area Name</label>
<input type="text" name="name" class="form-control mb-3" required>

<label>Description</label>
<textarea name="description" class="form-control mb-3"></textarea>

<button class="btn btn-success" name="save">Save area</button>

</form>

</div>
</div>

</div>

<?php include '../includes/footer.php'; ?>