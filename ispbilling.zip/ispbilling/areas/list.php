<?php
include '../config/db.php';
if(isset($_POST['save'])){

    $name = mysqli_real_escape_string($conn,$_POST['area_name']);
    $remarks = mysqli_real_escape_string($conn,$_POST['remarks']);

    $result = mysqli_query($conn,"
        INSERT INTO areas(name,remarks)
        VALUES('$name','$remarks')
    ");

    if(!$result){
        die("SQL Error: ".mysqli_error($conn));
    }

    die("DATA SAVED");
}

include '../includes/sidebar.php';
include '../includes/topbar.php';
?>


<div class="main-content">

<div class="card shadow border-0">

    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

        <h4 class="mb-0">🌍 Area Management</h4>

        <div>

            <button class="btn btn-light btn-sm"
                    data-bs-toggle="modal"
                    data-bs-target="#addAreaModal">
                ➕
            </button>

            <a href="list.php" class="btn btn-light btn-sm">
                🔄
            </a>

        </div>

    </div>

    <div class="card-body">

        <div class="card shadow-sm border-0 mb-3">

    <div class="card-body text-white"
         style="background:linear-gradient(90deg,#1e88e5,#42a5f5);border-radius:6px;">

        <div class="row align-items-center">

            <div class="col-md-6">

                ⚙ Total Data :
                <span class="badge bg-light text-primary">

                    <?php
                    echo mysqli_num_rows(
                    mysqli_query($conn,"SELECT * FROM areas")
                    );
                    ?>

                </span>

            </div>

            <div class="col-md-6">

                <form method="GET">

                    <input
                        type="text"
                        name="search"
                        class="form-control"
                        placeholder="Search Area">

                </form>

            </div>

        </div>

    </div>

</div>

        <table class="table table-bordered table-hover">

            <thead class="table-dark">

                <tr>
                    <th>#</th>
                    <th>Area</th>
                    <th>Remarks</th>
                    <th width="200">Action</th>
                </tr>

            </thead>

            <tbody>

            <?php

            $sql = "SELECT * FROM areas ORDER BY id DESC";

            if(isset($_GET['search']) && $_GET['search']!=''){

                $search = mysqli_real_escape_string(
                    $conn,
                    $_GET['search']
                );

                $sql = "SELECT * FROM areas
                        WHERE area_name LIKE '%$search%'
                        ORDER BY id DESC";
            }

            $data = mysqli_query($conn,$sql);

            $i = 1;

            while($row = mysqli_fetch_assoc($data)){
            ?>

            <tr>

                <td><?= $i++ ?></td>

                <td><?= $row['name'] ?></td>

                <td><?= $row['remarks'] ?></td>

                <td>

                    <a href="edit.php?id=<?= $row['id'] ?>"
                       class="btn btn-warning btn-sm">
                       Edit
                    </a>

                    <a href="delete.php?id=<?= $row['id'] ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Delete Area?')">
                       Delete
                    </a>

                </td>

            </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>

</div>

</div>


<!-- ADD AREA MODAL -->

<div class="modal fade"
     id="addAreaModal"
     tabindex="-1">

    <div class="modal-dialog">

        <div class="modal-content">

            <form method="POST">

                <div class="modal-header">

                    <h5 class="modal-title">
                        Add New Area
                    </h5>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal">
                    </button>

                </div>

                <div class="modal-body">

                    <div class="mb-3">

                        <label>Area Name</label>

                        <input type="text"
                               name="area_name"
                               class="form-control"
                               required>

                    </div>

                    <div class="mb-3">

                        <label>Remarks</label>

                        <textarea
                            name="remarks"
                            class="form-control"
                            rows="3"></textarea>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button"
                            class="btn btn-secondary"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit"
                            name="save"
                            class="btn btn-success">
                        Save
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<?php

if(isset($_POST['save'])){

    $area_name = mysqli_real_escape_string(
        $conn,
        $_POST['area_name']
    );

    $remarks = mysqli_real_escape_string(
        $conn,
        $_POST['remarks']
    );

    mysqli_query($conn,"
        INSERT INTO areas(
        area_name,
        remarks
        )
        VALUES(
        '$area_name',
        '$remarks'
        )
    ");

    echo "<script>
    location='list.php';
    </script>";
}

?>

<?php include '../includes/footer.php'; ?>