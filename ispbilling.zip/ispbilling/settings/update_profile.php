<?php
session_start();
include "../config/db.php";

$user_id = $_SESSION['user_id'];

$username = $_POST['username'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';

mysqli_query($conn,"UPDATE users SET 
username='$username',
phone='$phone',
email='$email'
WHERE id='$user_id'");

header("Location: profile.php");
exit();
?>