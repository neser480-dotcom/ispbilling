<?php
session_start();
include "../config/db.php";

$user_id = $_SESSION['user_id'];

$pass1 = $_POST['pass1'];
$pass2 = $_POST['pass2'];

if($pass1 != $pass2){
    die("Password not match");
}

if(strlen($pass1) < 4){
    die("Password too short");
}

$hash = password_hash($pass1, PASSWORD_BCRYPT);

mysqli_query($conn,"UPDATE users SET password='$hash' WHERE id='$user_id'");

header("Location: profile.php");
exit();
?>