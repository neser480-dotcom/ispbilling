<?php
include '../includes/sidebar.php';
include '../includes/topbar.php';
?>
<style>
.permission-box{
    background:#eef9ff;
    border:1px solid #d6eefc;
    border-radius:8px;
    padding:10px 12px;
    margin-bottom:10px;
    color:#0d6efd;   /* লেখার রং */
    font-weight:600;
}

.permission-box:hover{
    background:#dff4ff;
}

.profile-header{
    background:linear-gradient(90deg,#007bff,#00c6ff);
    color:#fff;
    padding:15px;
    text-align:center;
    border-radius:5px 5px 0 0;
    font-size:24px;
    font-weight:600;
}
</style>
<div class="main-content">

<div class="card shadow-sm border-0">

    <div class="card-header bg-primary text-white text-center">
        <h4 class="mb-0">Profile</h4>
    </div>

    <div class="card-body">

        <ul class="nav nav-tabs" id="profileTabs">

            <li class="nav-item">
                <button class="nav-link active"
                        data-bs-toggle="tab"
                        data-bs-target="#settings">
                    Settings
                </button>
            </li>

            <li class="nav-item">
                <button class="nav-link"
                        data-bs-toggle="tab"
                        data-bs-target="#profile">
                    Profile
                </button>
            </li>

            <li class="nav-item">
                <button class="nav-link"
                        data-bs-toggle="tab"
                        data-bs-target="#control">
                    Control Panel
                </button>
            </li>

        </ul>

        <div class="tab-content pt-4">

            <!-- SETTINGS -->
            <div class="tab-pane fade show active" id="settings">

                <div class="row">

                    <div class="col-md-6">

                        <h5>Update Profile</h5>

                        <div class="mb-3">
                            <label>Name</label>
                            <input type="text" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label>Company</label>
                            <input type="text" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label>Mobile</label>
                            <input type="text" class="form-control">
                        </div>

                        <button class="btn btn-primary">
                            Update Profile
                        </button>

                    </div>

                    <div class="col-md-6">

                        <h5>Change Password</h5>

                        <div class="mb-3">
                            <label>Old Password</label>
                            <input type="password" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label>New Password</label>
                            <input type="password" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control">
                        </div>

                        <button class="btn btn-success">
                            Change Password
                        </button>

                    </div>

                </div>

            </div>

            <!-- PROFILE -->
            <div class="tab-pane fade" id="profile">

                <table class="table table-bordered">

                    <tr>
                        <th>Name</th>
                        <td>Admin</td>
                    </tr>

                    <tr>
                        <th>Email</th>
                        <td>admin@gmail.com</td>
                    </tr>

                    <tr>
                        <th>Mobile</th>
                        <td>017xxxxxxxx</td>
                    </tr>

                    <tr>
                        <th>Role</th>
                        <td>Super Admin</td>
                    </tr>

                    <tr>
                        <th>Status</th>
                        <td>
                            <span class="badge bg-success">
                                Active
                            </span>
                        </td>
                    </tr>

                </table>

            </div>

            <!-- CONTROL PANEL -->
            <div class="tab-pane fade" id="control">

               <div class="row g-3">

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Customer Auto Generate</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Mikrotik Delete</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Promise Date</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Report Delete</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Expenditure Delete</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Area Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Status Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Billing Cycle Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Promise Date Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Auto Disable Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Package Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Transfer To Reseller</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Customer Delete</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Customer Mikrotik Update</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Customer Auto Connection</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Customer Recharge</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Add Customer With Mobile</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Instant Recharge Bill Print</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Inactive/Offline Customer Delete</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Reseller Add</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Multiple Manager</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Reseller Customer Bulk Status Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Reseller Customer Bulk Promise Date Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Pole Box</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Daily Recharge Feature</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Unpaid Customer Bulk SMS</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Reseller Customer Bulk Auto Connection Edit</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Show Customer Parent Package</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Reseller Minus Balance</div></div>

<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox"> Bulk Payment Status Edit</div></div>

</div>

            </div>

        </div>

    </div>

</div>

</div>

<?php include '../includes/footer.php'; ?>