<?php

include '../includes/auth.php';
include '../config/db.php';

$msg = '';

if(isset($_POST['save']))
{
    $company_name = $_POST['company_name'];
    $company_phone = $_POST['company_phone'];
    $company_email = $_POST['company_email'];
    $company_address = $_POST['company_address'];

    $logo = '';

    if(!empty($_FILES['logo']['name']))
    {
        $logo = time().'_'.$_FILES['logo']['name'];

        move_uploaded_file(
    $_FILES['logo']['tmp_name'],
    __DIR__.'/../uploads/logo/'.$logo
        );

        mysqli_query($conn,"
        UPDATE settings SET
        company_name='$company_name',
        company_phone='$company_phone',
        company_email='$company_email',
        company_address='$company_address',
        logo='$logo'
        WHERE id=1
        ");
    }
    else
    {
        mysqli_query($conn,"
        UPDATE settings SET
        company_name='$company_name',
        company_phone='$company_phone',
        company_email='$company_email',
        company_address='$company_address'
        WHERE id=1
        ");
    }

    $msg = "Settings Saved Successfully";
}

$setting = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM settings WHERE id=1")
);

include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="container-fluid">

<div class="card">

<div class="card-header bg-primary text-white">
Company Settings
</div>

<div class="card-body">

<?php if($msg){ ?>
<div class="alert alert-success">
<?= $msg ?>
</div>
<?php } ?>

<form method="post" enctype="multipart/form-data">

<div class="mb-3">
<label>Company Name</label>
<input type="text"
name="company_name"
class="form-control"
value="<?= $setting['company_name'] ?>">
</div>

<div class="mb-3">
<label>Phone</label>
<input type="text"
name="company_phone"
class="form-control"
value="<?= $setting['company_phone'] ?>">
</div>

<div class="mb-3">
<label>Email</label>
<input type="text"
name="company_email"
class="form-control"
value="<?= $setting['company_email'] ?>">
</div>

<div class="mb-3">
<label>Address</label>
<textarea
name="company_address"
class="form-control"><?= $setting['company_address'] ?></textarea>
</div>

<div class="mb-3">
<label>Logo Upload</label>
<input type="file"
name="logo"
class="form-control">
</div>

<?php if(!empty($settings['logo'])){ ?>
<img src="../uploads/logo/<?= $settings['logo'] ?>"
style="height:80px;width:auto;border:1px solid #ddd;padding:5px;">
<?php } ?>

<button
type="submit"
name="save"
class="btn btn-success">
Save Settings
</button>

</form>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>