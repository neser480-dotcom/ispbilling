<?php
include '../config/db.php';
include '../includes/header.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$data = mysqli_query($conn,"
SELECT *
FROM customers
WHERE status='Active'
ORDER BY id DESC
");

$total = mysqli_num_rows($data);
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white"
style="background:linear-gradient(90deg,#28a745,#00c851);">

<h5 class="mb-0">
🟢 Online Customer
</h5>

</div>

<div class="card-body">

<div class="alert alert-success">
Total Online : <b><?= $total ?></b>
</div>

<table class="table table-bordered table-hover">

<thead class="table-success">

<tr>
<th>ID</th>
<th>Customer ID</th>
<th>Name</th>
<th>Mobile</th>
<th>PPPoE</th>
<th>Status</th>
</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>
<td><?= $row['customer_id'] ?></td>
<td><?= $row['name'] ?></td>
<td><?= $row['phone'] ?></td>
<td><?= $row['pppoe_username'] ?></td>

<td>
<span class="badge bg-success">
Online
</span>
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>