<?php
include '../config/db.php';
include '../includes/sidebar.php';
include '../includes/topbar.php';

$data = mysqli_query($conn,"
SELECT *
FROM customers
WHERE status='Active'
ORDER BY id DESC
");

$total = mysqli_num_rows($data);
?>

<div class="main-content">

<div class="card shadow border-0">

<div class="card-header text-white d-flex justify-content-between align-items-center"
style="background:linear-gradient(90deg,#6610f2,#8e44ad);">

<h5 class="mb-0">
📶 Bandwidth Monitor
</h5>

<a href="bandwidth.php" class="btn btn-light btn-sm">
<i class="fa fa-rotate-right"></i>
 Refresh
</a>

</div>

<div class="card-body">

<div class="alert alert-primary">
Total Active User : <b><?= $total ?></b>
</div>

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-primary">

<tr>
<th>ID</th>
<th>Customer</th>
<th>PPPoE</th>
<th>Package</th>
<th>Download</th>
<th>Upload</th>
<th>Status</th>
</tr>

</thead>

<tbody>

<?php while($row=mysqli_fetch_assoc($data)){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= $row['name'] ?></td>

<td><?= $row['pppoe_username'] ?></td>

<td><?= $row['package_name'] ?></td>

<td>
<span class="badge bg-success">
0 Mbps
</span>
</td>

<td>
<span class="badge bg-info">
0 Mbps
</span>
</td>

<td>
<span class="badge bg-primary">
Monitoring
</span>
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</div>

</div>

<?php include '../includes/footer.php'; ?>